<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Support\Facades\Auth;

class ClearanceMiddleware {
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next) {        
        if (Auth::user()->hasPermissionTo('Administratoriaus roles ir leidimai')) //If user has this //permission
        {
            return $next($request);
        }

        if ($request->is('posts/create'))//If user is creating a post
         {
            if (!Auth::user()->hasPermissionTo('Create Post'))
         {
                abort('401');
            } 
         else {
                return $next($request);
            }
        }

        if ($request->is('posts/*/edit')) //If user is editing a post
         {
            if (!Auth::user()->hasPermissionTo('Edit Post')) {
                abort('401');
            } else {
                return $next($request);
            }
        }

        if ($request->isMethod('Delete')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Delete Post')) {
                abort('401');
            } 
         else 
         {
                return $next($request);
            }
        }
         if ($request->isMethod('parts/view-parts')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Perziureti detale')) {
                abort('401');
            } 
         else 
         {
                return $next($request);
            }
        }
        if ($request->is('parts/add-parts')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Sukurti detale'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }
        if ($request->is('parts/edit-parts/*')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Redaguoti detale'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }

        if ($request->is('parts/delete-parts/*')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Istrinti detale'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }
        if ($request->is('cars/edit-cars/*')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Redaguoti auto'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }
        if ($request->is('cars/delete-cars/*')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Istrinti auto'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }
        if ($request->is('cars/add-cars')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Sukurti auto'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }
        if ($request->is('cars/view-cars')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Perziureti auto'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }
     /*   if ($request->is('inventory/parts-gallery/*')) //If user is deleting a post
         {
            if (!Auth::user()->hasPermissionTo('Perziureti auto'))
        {
             abort('401');

        }
         else 
         {
                return $next($request);
            }
        }*/

        return $next($request);
    }
}