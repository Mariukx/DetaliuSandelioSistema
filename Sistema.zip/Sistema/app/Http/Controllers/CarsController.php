<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Cars;
use App\Parts;
use App\Location;
use App\Warehouse;
use DB;
use PDF;
use Illuminate\Support\Facades\Input;
use Image;


class CarsController extends Controller
{
   //use Authorizable; sukurti 
 public function __construct() {
        $this->middleware(['auth', 'clearance'])->except('index', 'inventory/parts-gallery/*');
    }

    public function addCars(Request $request){
        if($request->isMethod('post')){
            $data= $request->all();
            $car = new Cars;
            $car->brand=$data['brand'];
            $car->model=$data['model'];
            $car->year=$data['year'];
            $car->fuel=$data['fuel'];
            $car->gearbox=$data['gearbox'];
            $car->cubature=$data['cubature'];
            $car->power=$data['power'];
            $car->body_type=$data['body_type'];
            $car->color=$data['color'];
            $car->wheel=$data['wheel'];
            $car->mileage=$data['mileage'];
            if($request->hasFile('image')){
                $image_tmp = Input::file('image');
                if($image_tmp->isValid()){
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999).'.'.$extension;
                    $large_image_path = 'images/backend_images/cars/large/'.$filename;
                    $medium_image_path = 'images/backend_images/cars/medium/'.$filename;
                    $small_image_path = 'images/backend_images/cars/small/'.$filename;
                    // Resize Images
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(900,700)->save($medium_image_path);
                    Image::make($image_tmp)->resize(450,350)->save($small_image_path);

                    // Store image name in products table
                    $car->image = $filename;
                }
            }
            $car->save();
            return redirect('/cars/view-cars')->with('flash_message_success','Automobilis "'.$car->brand.' '.$car->model.'" sėkmingai pridėtas!');

        }


        return view('cars.add_cars');

    }

    public function editCars(Request $request, $id = null ){
        
        if($request->isMethod('post')){
            $data = $request->all();
             if($request->hasFile('image')){
                $image_tmp = Input::file('image');
                if($image_tmp->isValid()){
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999).'.'.$extension;
                    $large_image_path = 'images/backend_images/cars/large/'.$filename;
                    $medium_image_path = 'images/backend_images/cars/medium/'.$filename;
                    $small_image_path = 'images/backend_images/cars/small/'.$filename;
                    // Resize Images
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(900,700)->save($medium_image_path);
                    Image::make($image_tmp)->resize(450,350)->save($small_image_path);
                   
                }
            }else if(!empty($data['current_image'])){
                $filename = $data['current_image'];
            }else{
                $filename = '';
            }

            Cars::where(['car_id'=>$id])->update(['brand'=>$data['brand'],'model'=>$data['model'],'year'=>$data['year'],'fuel'=>$data['fuel'],'gearbox'=>$data['gearbox'],'cubature'=>$data['cubature'],'power'=>$data['power'],'body_type'=>$data['body_type'],'color'=>$data['color'],'wheel'=>$data['wheel'],'mileage'=>$data['mileage'], 'image'=>$filename  ]);
            return redirect('/cars/view-cars')->with('flash_message_success','Automobilis atnaujintas sėkmingai!');
        }
        $carDetails = Cars::where(['car_id'=>$id])->first();
        return view('cars.edit_cars')->with(compact('carDetails'));
    }

    public function deleteCars(Request $request, $id = null){
        if(!empty($id)){
            Cars::where(['car_id'=>$id])->delete();
            return redirect()->back()->with('flash_message_success','Automobilis sėkmingai ištrintas!');
        }
    }
    public function deleteCarImage($id = null){
        Cars::where(['car_id'=>$id])->update(['image'=>'']);
        return redirect()->back()->with('flash_message_success','Automobilio nuotrauka panaikinta!');
    }

    public function viewCars(){
        $cars = Cars::get();
        return view('cars.view_cars')->with(compact('cars'));
    }

   public function pdf(){
        $cars = Cars::all();
        $pdf = PDF::loadView('cars.print_cars', ['cars' => $cars]);
        return $pdf->download('autommobiliai.pdf');
    }

     public function pdf1(){
       $parts = DB::table('parts')
            ->join('cars', 'parts.car_id', '=', 'cars.car_id')
            ->join('locations', 'parts.location_id', '=', 'locations.location_id')
            ->join('warehouses', 'parts.wh_id', '=', 'warehouses.wh_id')
            ->select('parts.*', 'cars.*', 'locations.*','w_address')
            ->get();
        $pdf = PDF::loadView('inventory.print_carparts', ['parts' => $parts]);
        return $pdf->download('autommobilių dalys.pdf');
    }

    

    /*
    
   public function generate_pdf() {
    $parts = [
        'foo' => 'bar'
    ];
    $pdf = PDF::loadView('inventory.carparts', $parts);
    return $pdf->stream('document.pdf');
}*/
}
