<?php

namespace App\Http\Controllers;


use App\Cars;
use App\Parts;
use App\Location;
use App\Warehouse;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Image;
use View;

class SearchController extends Controller
{

	public function filterCars(Request $request, Cars $cars){
        
        $brand = $request->input('brand', null); 
        $model = $request->input('model', null); 
        $year = $request->input('year', null); 
        $year1 = $request->input('year1', null);

				$query = Cars::query();
				if($brand != null) {
				    $query->where('brand', Input::get('brand'));
				}
				if($model != null) {
				    $query->where('model',  'LIKE', '%' . $model . '%');
				}
                if($year != null)
                {
                    $query->where('year', '>=', $year);
                }
                if($year1 != null)
                {
                    $query->where('year', '<=', $year1);
                }

				$cars = $query->get();
				return View::make('cars.view_cars')->with('cars', $cars);

    }
    public function filterCarParts(Request $request, Parts $parts){
        
        $brand = $request->input('brand', null); 
        $model = $request->input('model', null); 
        $year = $request->input('year', null); 
        $year1 = $request->input('year1', null);

                $query = Parts::query()
                    ->join('cars', 'parts.car_id', '=', 'cars.car_id')
                    ->join('locations', 'parts.location_id', '=', 'locations.location_id')
                    ->join('warehouses', 'parts.wh_id', '=', 'warehouses.wh_id')
                    ->select('parts.*', 'cars.*', 'locations.*','w_address');
                   
                if($brand != null) {
                    $query->where('brand', Input::get('brand'));
                }
                if($model != null) {
                    $query->where('model',  'LIKE', '%' . $model . '%');
                }
                if($year != null)
                {
                    $query->where('year', '>=', $year);
                }
                if($year1 != null)
                {
                    $query->where('year', '<=', $year1);
                }

                $parts = $query->get();
                return View::make('inventory.carparts')->with('parts', $parts);
    }
}