<?php

namespace App\Http\Controllers;

use App\Cars;
use Illuminate\Http\Request;
use App\Parts;
use App\Part_info;
use App\Warehouse;
use App\Location;
use DB;
use PDF;
use Illuminate\Support\Facades\Input;
use Image;
use View;

class PartsController extends Controller
{
 public function __construct() {
        $this->middleware(['auth', 'clearance'])->except('index', 'inventory/parts-gallery/*');
    }

    public function addParts(Request $request){
        if($request->isMethod('post')){
            $data= $request->all();
            
            $part = new Parts;
            $part->car_id=$data['car_id'];
            $part->wh_id=$data['wh_id'];
            $part->p_name=$data['p_name'];
         
            $part->p_price=$data['p_price'];
            $part->p_quantity=$data['p_quantity'];
          
            $part->p_color=$data['p_color'];
            $part->p_code=$data['p_code'];
            $part->p_color_code=$data['p_color_code'];
            $part->p_vendor=$data['p_vendor'];
            $part->p_side=$data['p_side'];
            $part->p_description=$data['p_description'];
            $part->location_id=$data['location_id'];
            if($request->hasFile('p_image')){
                $image_tmp = Input::file('p_image');
                if($image_tmp->isValid()){
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999).'.'.$extension;
                    $large_image_path = 'images/backend_images/parts/large/'.$filename;
                    $medium_image_path = 'images/backend_images/parts/medium/'.$filename;
                    $small_image_path = 'images/backend_images/parts/small/'.$filename;
                    // Resize Images
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(900,700)->save($medium_image_path);
                    Image::make($image_tmp)->resize(450,350)->save($small_image_path);

                    // Store image name in products table
                    $part->p_image = $filename;
                    echo "string";
                }
            }
            $part->save();

           /* $info = new Part_info;
            $info->p_price = $request->p_price;
            $info->save();*/
            return redirect('/parts/view-parts')->with('flash_message_success','Detalė "'.$part->p_name.'" sėkmingai pridėta!');
        }

        $cars = Cars::select('car_id', DB::raw("concat(brand,' ',model,' - ', year,'m, ', power,' kW, ', cubature, ' L'  ) as id_name"))
            ->orderBy('brand')
            ->pluck('id_name', 'car_id');

        
        $warehouse = Warehouse::select('wh_id', DB::raw("concat(w_address,', ID', ' = ', wh_id) as loc_add"))
            ->orderBy('w_address')
            ->pluck('loc_add', 'wh_id');
        $location = Location::select('location_id', DB::raw("concat(section,stack,shelve,slot,' - ', 'Sandėlio ID = ',wh_id ) as loc_code"))
            ->orderBy('section')
            ->pluck('loc_code', 'location_id');

        return view('parts.add_parts' , compact('cars','warehouse','location'));
    }

    public function viewParts(){
        $parts = DB::table('parts')
            ->join('cars', 'parts.car_id', '=', 'cars.car_id')
            ->join('locations', 'parts.location_id', '=', 'locations.location_id')
            ->join('warehouses', 'parts.wh_id', '=', 'warehouses.wh_id')
            ->select('parts.*', 'cars.*', 'locations.*','w_address')
            ->get();
            return view('parts.view_parts', ['parts' => $parts]);
    }


    public function editParts(Request $request, $id = null ){
        if($request->isMethod('post')){
            $data = $request->all();
             if($request->hasFile('p_image')){
                $image_tmp = Input::file('p_image');
                if($image_tmp->isValid()){
                    $extension = $image_tmp->getClientOriginalExtension();
                    $filename = rand(111,99999).'.'.$extension;
                    $large_image_path = 'images/backend_images/parts/large/'.$filename;
                    $medium_image_path = 'images/backend_images/parts/medium/'.$filename;
                    $small_image_path = 'images/backend_images/parts/small/'.$filename;
                    // Resize Images
                    Image::make($image_tmp)->save($large_image_path);
                    Image::make($image_tmp)->resize(900,700)->save($medium_image_path);
                    Image::make($image_tmp)->resize(450,350)->save($small_image_path);
                   
                }
            }else if(!empty($data['current_image'])){
                $filename = $data['current_image'];
            }else{
                $filename = '';
            }

            Parts::where(['part_id'=>$id])->update(['car_id'=>$data['car_id'],'wh_id'=>$data['wh_id'],'p_name'=>$data['p_name'],'p_price'=>$data['p_price'],'p_quantity'=>$data['p_quantity'],'p_color'=>$data['p_color'],'p_code'=>$data['p_code'],'p_color_code'=>$data['p_color_code'],'p_side'=>$data['p_side'],'p_vendor'=>$data['p_vendor'],'p_description'=>$data['p_description'],'location_id'=>$data['location_id'], 'p_image'=>$filename ]);
            return redirect('/parts/view-parts')->with('flash_message_success','Atnaujinta sėkmingai!');
        }

        $partDetails = Parts::where(['part_id'=>$id])->first();
        $cars = Cars::select('car_id', DB::raw("concat(brand,' ',model,' - ', year,'m, ', power,' kW, ', cubature, ' L'  ) as id_name"))
            ->orderBy('brand')
            ->pluck('id_name', 'car_id');
        $warehouse = Warehouse::select('wh_id', DB::raw("concat(w_address,', ID', ' = ', wh_id) as loc_add"))
            ->orderBy('w_address')
            ->pluck('loc_add', 'wh_id');
        $location = Location::select('location_id', DB::raw("concat(section,stack,shelve,slot,' - ', 'Sandėlio ID = ',wh_id ) as loc_code"))
            ->orderBy('section')
            ->pluck('loc_code', 'location_id');
            
        return view('parts.edit_parts')->with(compact('partDetails','cars','warehouse','location', $cars));
    }

    public function deleteParts(Request $request, $id = null){
        if(!empty($id)){
            Parts::where(['part_id'=>$id])->delete();
          
            return redirect()->back()->with('flash_message_success','Detalė ištrinta sėkmingai!');
        }
        
    }
     public function deletePartImage($id = null){
        Parts::where(['part_id'=>$id])->update(['image'=>'']);
        return redirect()->back()->with('flash_message_success','Detalės nuotrauka panaikinta!');
    }

    public function viewCarParts(){
        
        $parts = DB::table('parts')
            ->join('cars', 'parts.car_id', '=', 'cars.car_id')
            ->join('locations', 'parts.location_id', '=', 'locations.location_id')
            ->join('warehouses', 'parts.wh_id', '=', 'warehouses.wh_id')
            ->select('parts.*', 'cars.*', 'locations.*','w_address')
            //->select(DB::raw('sum(parts.p_quantity*parts.p_price) AS total_sales'))
            
            ->get();
            return view('inventory.carparts', ['parts' => $parts]);
    }

    
 public function pdf(){
        $parts = Parts::all();
        $pdf = PDF::loadView('parts.print_parts', ['parts' => $parts]);
        return $pdf->download('dalys.pdf');
    }

    

     public function Order($id = null){
        $parts = Parts::select('parts.*', 'cars.*')
        ->join('cars', 'parts.car_id', '=', 'cars.car_id' )
     
        ->where(['parts.part_id'=>$id])
       
        ->get();

            return view('inventory.send_order', ['parts' => $parts ]);
     }
    
}
