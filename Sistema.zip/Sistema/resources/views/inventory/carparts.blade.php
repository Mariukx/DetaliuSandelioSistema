
@extends('layouts.app')

@section('title', '| Car parts')

@section('content')


<!--main-container-part-->

<!--breadcrumbs-->
<head>
<!--<link rel="stylesheet" type="text/css" href=" https://cdn.datatables.net/1.10.16/css/jquery.dataTables.min.css">
<link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/buttons/1.5.1/css/buttons.dataTables.min.css">
<link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
<link href="{{ asset('css/styles.css') }}" rel="stylesheet">
    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
    <script src="https://use.fontawesome.com/9712be8772.js"></script>-->
  </head>
  <body>
 <div class="col-lg-10 col-lg-offset-1 "  >
        <div class="widget-box" > 
          <div class="widget-content" style="box-shadow: 2px 3px 2px 0px grey; background-color: #F0F8FF">
        <form enctype="multipart/form-data" class="form-horizontal" method="get" action="{{ url('/inventory/carparts1') }}" name="add_product" id="add_product" novalidate="novalidate"> 
            
              <div class="row">
                <div class="control-group col-xs-6 mb-3" >{{ csrf_field() }}
                                    
                                    <div class="controls" >
                                    
                                        <select required aria-required="true"  class="form-control" id="brand" name="brand" onchange="fillSelect(this.value,this.form['model'])">
                                         <option selected value="">Markė:</option>
                                          <option value="Honda">Honda</option>
                                          <option value="Hyundai">Hyundai</option>
                                          <option value="Kia">Kia</option>
                                          <option value="Lexus">Lexus</option>
                                          <option value="Mazda">Mazda</option>
                                          <option value="Mitshubishi">Mitsubishi</option>
                                          <option value="Nissan">Nissan</option>
                                          <option value="Subaru">Subaru</option>
                                          <option value="Suzuki">Suzuki</option>
                                          <option value="Toyota">Toyota</option>
                                        </select>
                                    </div>
                                </div>

                                 <div class="control-group col-xs-6">
                                    
                                    <div class="controls" >
                                       
                                         <select required aria-required="true"  class="form-control" id="model" name="model" >
                                            <option selected value="">Modelis:</option>
                     
                                         </select>
                                    </div>
                                </div>
                              
                              <div class="control-group col-xs-6" >
                                
                                    <div class="controls"  >
                                         <select required aria-required="true"   class="form-control " id="year" name="year" >
                                          <option selected value="">Metai nuo:</option>
                                          <option>2018</option>
                                          <option>2017</option>
                                          <option>2016</option>
                                          <option>2015</option>
                                          <option>2014</option>
                                          <option>2013</option>
                                          <option>2012</option>
                                          <option>2011</option>
                                          <option>2010</option>
                                          <option>2009</option>
                                          <option>2008</option>
                                          <option>2007</option>
                                          <option>2006</option>
                                          <option>2005</option>
                                          <option>2004</option>
                                          <option>2003</option>
                                          <option>2002</option>
                                          <option>2001</option>
                                          <option>2000</option>
                                          <option>1999</option>
                                          <option>1998</option>
                                          <option>1997</option>
                                          <option>1996</option>
                                          <option>1995</option>
                                          <option>1994</option>
                                        </select>
                                    </div>
                                </div>
                              
                              
                                <div class="control-group col-xs-6" >
                                  
                                    <div class="controls"  >
                                         <select required aria-required="true"   class="form-control " id="year1" name="year1" >
                                          <option selected value="">Metai iki:</option>
                                          <option>2018</option>
                                          <option>2017</option>
                                          <option>2016</option>
                                          <option>2015</option>
                                          <option>2014</option>
                                          <option>2013</option>
                                          <option>2012</option>
                                          <option>2011</option>
                                          <option>2010</option>
                                          <option>2009</option>
                                          <option>2008</option>
                                          <option>2007</option>
                                          <option>2006</option>
                                          <option>2005</option>
                                          <option>2004</option>
                                          <option>2003</option>
                                          <option>2002</option>
                                          <option>2001</option>
                                          <option>2000</option>
                                          <option>1999</option>
                                          <option>1998</option>
                                          <option>1997</option>
                                          <option>1996</option>
                                          <option>1995</option>
                                          <option>1994</option>
                                        </select>
                                    </div>
                                </div>
                                
            </div>
         
          <div class="form-actions col-lg-offset-11 ">
                <input type="submit" value="Filtruoti" class="btn btn-success">
              </div>
            </form>
          </div>
          </div>
        </div>
<div class="col-lg-10 col-lg-offset-1">
@can('Atspausdinti PDF')<a class="btn btn-success " href="{{ url('/inventory/print-carparts') }}">Atspausdinti PDF</a>@endcan
                   <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>Sandėlio duomenys</h5>
                        </div>
                        <div class="widget-content table-responsive">
                            <table id="inv" class="table data-table table-bordered  table-responsive" >
                                <thead>
                                <tr>
                                      <th style="width: 5%" >Nr.</th>
                                    <th style="width: 8%">Detalės pavadinimas</th>
                                    <th style="width: 18%">Automobilis</th>
                                    <th style="width: 5%">Kaina</th>
                                    <th style="width: 3%">Kiekis</th>
                                    
                                    <th style="width: 5%">Spalva</th>
                                     <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 5%">Gamintojas</th>
                                    <th style="width: 5%">Detalės pusė</th>
                                    <th style="width: 7%">Aprašymas</th>
                                    <th style="width: 6%">Adresas</th>
                                    <th style="width: 3%">Vietos kodas</th>
                                    
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th style="width: 8%">Detalės pavadinimas</th>
                                    <th style="width: 18%">Automobilis</th>
                                    <th style="width: 5%">Kaina</th>
                                    <th style="width: 3%">Kiekis</th>
                                    <th style="width: 5%">Spalva</th>
                                    <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 5%">Gamintojas</th>
                                    <th style="width: 5%">Detalės pusė</th>
                                    <th style="width: 7%">Aprašymas</th>
                                    <th style="width: 6%">Adresas</th>
                                    <th style="width: 3%">Vietos kodas</th>
                                   
                                    
                                </tr>
                                </tfoot>
                                <tbody>
                                  <?php
                                  $i = 0;
                                  ?>
                               @foreach($parts as $part)
                               <tr class="gradeX">
                                   <td>{!! ++$i !!}</td>
                                   <td>{!! $part -> p_name !!}</td>
                                   <td>{!! $part -> brand !!}  {!! $part -> model !!} - {!! $part -> year !!} m.,  {!! $part -> power !!} kW,  {!! $part -> cubature !!} L</td>
                                  
                                   <td>{!! $part -> p_price !!}</td>
                                   <td>{!! $part -> p_quantity !!}</td>
                                   <td>{!! $part -> p_color !!}</td>
                                   <td>{!! $part -> p_color_code !!}</td>
                                   <td>{!! $part -> p_code !!}</td>
                                   <td>{!! $part -> p_vendor !!}</td>
                                   <td>{!! $part -> p_side !!}</td>
                                   <td>{!! $part -> p_description !!}</td>
                                   <td>{!! $part -> w_address !!}</td> 
                                   <td>{!! $part -> section !!}{!! $part -> stack !!}{!! $part -> shelve !!}{!! $part -> slot !!}</td>
                               </tr>
                                @endforeach
                                </tbody>
                            </table>
                       <!--     <script type="text/javascript">
                             
                              $('#inv').DataTable( {
                                  dom: 'Bfrtip',
                                  buttons: [
                                      'print', 'excel'
                                  ]
                              } );
                         
                            </script>  -->
                             
    
       
              
                      </div>
                    </div>
                </div>
          <script type="text/javascript">
  
  var model = []; 
  model["Honda"] = ["Accord", "Civic","Civic Type R","CR-V","CRX","Element", "FR-V","Insight","Odissey","Prelude","S2000"];
  model["Hyundai"] = ["Accent", "Coupe", "Getz", "i30"];
  model["Kia"] = ["Cee'd","Optima","Picanto", "Rio", "Sorento"];
  model["Lexus"] = ["ES 200","ES 240","ES 250","ES 300","IS 200","IS 250","IS 300","IS 350","GS 300","HS 250h"];
  model["Mazda"] = ["121", "2","3","323","323F","5","6","626","MX-5","RX-8","Premacy","Xedos 9"];
  model["Mitshubishi"] = ["Carisma","Colt","Eclipse","Galant","Lancer","Lancer Evolution","Pajero","SpaceStar"];
  model["Nissan"] = ["Almera","Altima","Juke","Leaf","Micra","Murano","Note","Tino","Xtrail"];
  model["Subaru"] = ["Forester","Impreza","Legacy","Outback","WRX"];
  model["Suzuki"] = ["Alto","Grand Vitara","Liana","Swift","SX 4"];
  model["Toyota"] = ["Aygo","Avensis","Auris","Camry","Corrola","Corrola Verso","Highlander","Yaris","Land Cruiser","Previa","Prius","RAV4","Verso"];
  
  function fillSelect(nValue,nList){

    nList.options.length = 1;
    var curr = model[nValue];
    for (each in curr)
      {
       var nOption = document.createElement('option'); 
       nOption.appendChild(document.createTextNode(curr[each])); 
       nOption.setAttribute("value",curr[each]);       
       nList.appendChild(nOption); 
      }
  }

</script>
 <!--<script src="https://code.jquery.com/jquery-1.12.4.js"></script>
 <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.5.1/js/dataTables.buttons.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.flash.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/pdfmake.min.js"></script>
 <script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.32/vfs_fonts.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.html5.min.js"></script>
 <script src="https://cdn.datatables.net/buttons/1.5.1/js/buttons.print.min.js"></script>-->

<!--end-main-container-part-->
@endsection








