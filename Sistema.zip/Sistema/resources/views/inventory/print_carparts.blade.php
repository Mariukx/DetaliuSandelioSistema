<!Doctype html>
  <html lang="en">
   <head>
    <meta charset="UTF-8">
      <title>carparts</title>
                <style type="text/css">

                          #carparts {
                          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                          }

                          #carparts td, #carparts th {
                              border: 1px solid #ddd;
                              padding: 8px;
                          }

                          #carparts tr:nth-child(even){
                            background-color: #f2f2f2;
                          }

                          #carparts tr:hover {
                            background-color: #ddd;
                          }

                          #carparts th {
                              padding-top: 12px;
                              padding-bottom: 12px;
                              text-align: left;
                              background-color: #4CAF50;
                              color: white;
                          }
              </style>
   </head>

          <body>

            <h1>Automobilių dalys</h1>
                            <table id="carparts">
                                <thead>
                                <tr>
                                      <th style="width: 5%" >Nr.</th>
                                    <th style="width: 8%">Detalės pavadinimas</th>
                                    <th style="width: 18%">Automobilis</th>
                                    <th style="width: 5%">Kaina</th>
                                    <th style="width: 3%">Kiekis</th>
                                    <th style="width: 5%">Spalva</th>
                                    <th style="width: 5%">Gamintojas</th>
                                    <th style="width: 5%">Detalės pusė</th>
                                    <th style="width: 7%">Aprašymas</th>
                                    <th style="width: 6%">Adresas</th>
                                    <th style="width: 3%">Vietos kodas</th>
                                    
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th style="width: 8%">Detalės pavadinimas</th>
                                    <th style="width: 18%">Automobilis</th>
                                    <th style="width: 5%">Kaina</th>
                                    <th style="width: 3%">Kiekis</th>
                                    <th style="width: 5%">Spalva</th>
                                    <th style="width: 5%">Gamintojas</th>
                                    <th style="width: 5%">Detalės pusė</th>
                                    <th style="width: 7%">Aprašymas</th>
                                    <th style="width: 6%">Adresas</th>
                                    <th style="width: 3%">Vietos kodas</th>
                                   
                                    
                                </tr>
                                </tfoot>
                                <tbody>
                                  <?php
                                  $i = 0;
                                  ?>
                               @foreach($parts as $part)
                               <tr class="gradeX">
                                   <td>{!! ++$i !!}</td>
                                   <td>{!! $part -> p_name !!}</td>
                                   <td>{!! $part -> brand !!}  {!! $part -> model !!} - {!! $part -> year !!} m.,  {!! $part -> power !!} kW,  {!! $part -> cubature !!} L</td>
                                  
                                   <td>{!! $part -> p_price !!}</td>
                                   <td>{!! $part -> p_quantity !!}</td>
                                   <td>{!! $part -> p_color !!}</td>
                                   <td>{!! $part -> p_vendor !!}</td>
                                   <td>{!! $part -> p_side !!}</td>
                                   <td>{!! $part -> p_description !!}</td>
                                   <td>{!! $part -> w_address !!}</td> 
                                   <td>{!! $part -> section !!}{!! $part -> stack !!}{!! $part -> shelve !!}{!! $part -> slot !!}</td>
                               </tr>
                                @endforeach
                                </tbody>
                            </table>
       
       
          
          
          </body>
        </html>