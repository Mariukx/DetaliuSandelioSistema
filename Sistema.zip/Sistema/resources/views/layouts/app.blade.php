{{-- resources/views/layouts/app.blade.php --}}
<!DOCTYPE html>
<html lang="{{ config('app.locale') }}">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>{{ config('app.name', 'Carparts') }}</title>
   
    <!-- Styles -->
   <!-- <link href="{{ asset('css/app.css') }}" rel="stylesheet">-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 
   <!-- <link rel="stylesheet" href="{{asset('css/backend_css/bootstrap.min.css')}}" />
    <link rel="stylesheet" href="{{asset('css/backend_css/bootstrap-responsive.min.css')}}" />
    <link rel="stylesheet" href="{{asset('css/backend_css/fullcalendar.css')}}" />-->
   <link rel="stylesheet" href="{{asset('css/backend_css/matrix-style.css')}}" />
    <link rel="stylesheet" href="{{asset('css/backend_css/matrix-media.css')}}" />
    <link href="{{ asset('css/styles.css') }}" rel="stylesheet">

   <!-- <link rel="stylesheet" href="{{asset('css/backend_css/select2.css')}}" />
    <link href="{{asset('fonts/backend_fonts/css/font-awesome.css')}}" rel="stylesheet" />
    <link rel="stylesheet" href="{{asset('css/backend_css/jquery.gritter.css')}}" />-->
    <!-- Scripts -->
    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
    <script src="https://use.fontawesome.com/9712be8772.js"></script>
</head>
<body >
    <div id="app" style="margin-top:50px; margin-bottom: 1000px;">
        <nav class="navbar navbar-inverse navbar-fixed-top"  >
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    &nbsp;
                    <!-- Branding Image -->
                   <a href="{{ url('/') }}"><img src="{{asset('images/backend_images/logo.png')}}"></a>

                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <li><a href="{{ url('/index') }}">PAGRINDINIS</a></li>
                        @if (!Auth::guest())
                          <!--   <li><a href="{{ route('posts.create') }}">NAUJAS STRAIPSNIS</a></li>-->
                          @can('Perziureti detale') 
                            <li><a href="{{ url('/cars/view-cars') }}">AUTOMOBILIAI</a></li>
                           <li><a href="{{ url('/parts/view-parts') }}">DALYS</a></li>
                            <li><a href="{{ url('/inventory/carparts') }}">INVENTORIUS</a></li>@endcan
                            @can('Uzsakymai')<li><a href="{{ url('') }}">UŽSAKYMAI</a></li>@endcan
                                   <!--          <li><a href="{{ url('/cars/view-cars1') }}">test</a></li>-->
                         @endif
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        @if (Auth::guest())
                            <li><a href="{{ route('login') }}">PRISIJUNGTI</a></li>
                          <!--  <li><a href="{{ route('register') }}">REGISTRUOTIS</a></li> -->
                        @else
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    {{ Auth::user()->name }} <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        @role('Administratorius') {{-- Laravel-permission blade helper --}}
                                        <a href="{{ url('users') }}"><i class="fa fa-btn fa-unlock"></i> NAUDOTOJAI</a>
                                        <a href="{{ url('/inventory/carparts') }}"><i class="fa fa-archive"></i> 
                                        INVENTORIUS</a>
                                        <a href="{{ url('/cars/view-cars') }}"><i class="fa fa-btn fa-car"></i> AUTOMOBILIAI</a>
                                        <a href="{{ url('/parts/view-parts') }}"><i class="fa fa-cogs"></i></i> DALYS</a>
                                        @endrole
                                         @role('Vadybininkas') {{-- Laravel-permission blade helper --}}
                                        <a href="{{ url('*') }}"><i class="fa fa-file"></i> SĄSKAITOS</a>
                                        <a href="{{ url('/inventory/carparts') }}"><i class="fa fa-archive"></i> INVENTORIUS</a>

                                        @endrole
                                        @role('Sandėlininkas') {{-- Laravel-permission blade helper --}}
                                        <a href="{{ url('/cars/view-cars') }}"><i class="fa fa-btn fa-car"></i> AUTOMOBILIAI</a>
                                        <a href="{{ url('/parts/view-parts') }}"><i class="fa fa-cogs"></i> DALYS</a>
                                        <a href="{{ url('/inventory/carparts') }}"><i class="fa fa-archive"></i> INVENTORIUS</a>

                                        @endrole
                                        <a href="{{ route('logout') }}" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-arrow-right"></i>
                                       Atsijungti
                                               </a>

                                        <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                                </ul>
                            </li>
                        @endif
                    </ul>
                </div>
            </div>
        </nav>

        @if(Session::has('flash_message'))
            <div class="container">      
                <div class="alert alert-success"><em> {!! session('flash_message') !!}</em>
                </div>
            </div>
        @endif 

        <div class="row">
            <div class="col-md-8 col-md-offset-2">              
                @include ('errors.list') {{-- Including error file --}}
            </div>
        </div>

        @yield('content')

    </div>
<div class="footer" style="
position: fixed;
   left: 0;
   bottom: 0;
   width: 100%;
   background-color: #333;
   color: white;
   text-align: center;
   padding-top: 5px;">
  <p>Copyright © Marius Malinauskas 2018</p>
</div>
    <!-- Scripts -->
    <script src="{{ asset('js/app.js') }}"></script>
  
   

   <!--  <script src="{{asset('js/backend_js/jquery.min.js')}}"></script> 
    <script src="{{asset('js/backend_js/jquery.ui.custom.js')}}"></script> 
    <script src="{{asset('js/backend_js/bootstrap.min.js')}}"></script> 
    <script src="{{asset('js/backend_js/jquery.uniform.js')}}"></script> 
    <script src="{{asset('js/backend_js/select2.min.js')}}"></script> -->
    <script src="{{asset('js/backend_js/jquery.validate.js')}}"></script>
    <script src="{{asset('js/backend_js/matrix.js')}}"></script> 
    <script src="{{asset('js/backend_js/matrix.form_validation.js')}}"></script>
    <script src="{{asset('js/backend_js/jquery.dataTables.min.js')}}"></script>
   
    <script src="{{asset('js/backend_js/matrix.tables.js')}}"></script>
    <script src="{{asset('js/backend_js/jquery.printPage.js')}}"></script> 
 
   <!--    <script src="{{asset('js/backend_js/matrix.popover.js')}}"></script>-->
</body>
</html>




