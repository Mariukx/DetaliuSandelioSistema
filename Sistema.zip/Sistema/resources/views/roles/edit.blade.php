@extends('layouts.app')

@section('title', '| Edit Role')

@section('content')

<div class='col-lg-4 col-lg-offset-4'>
    <div class="widget-box">
        <div class="widget-content">
    <h1><i class='fa fa-key'></i> Redaguoti rolę "{{$role->name}}"</h1>
    <hr>

    {{ Form::model($role, array('route' => array('roles.update', $role->id), 'method' => 'PUT')) }}

    <div class="form-group">
        {{ Form::label('name', 'Rolės pavadinimas') }}
        {{ Form::text('name', null, array('class' => 'form-control')) }}
    </div>

    <h5><b>Priskirti leidimus</b></h5>
    @foreach ($permissions as $permission)

        {{Form::checkbox('permissions[]',  $permission->id, $role->permissions ) }}
        {{Form::label($permission->name, ucfirst($permission->name)) }}<br>

    @endforeach
    <br>
    {{ Form::submit('Išsaugoti', array('class' => 'btn btn-primary')) }}

    {{ Form::close() }}    
</div>
</div>
</div>
@endsection