{{-- \resources\views\permissions\create.blade.php --}}
@extends('layouts.app')

@section('title', '| Create Permission')

@section('content')

<div class='col-lg-4 col-lg-offset-4'>
<div class="widget-box">
    <div class="widget-content">
    <h1><i class='fa fa-key'></i> Sukurti leidimą</h1>
    <br>

    {{ Form::open(array('url' => 'permissions')) }}

    <div class="form-group">
        {{ Form::label('name', 'Pavadinimas') }}
        {{ Form::text('name', '', array('class' => 'form-control')) }}
    </div><br>
    @if(!$roles->isEmpty()) <!--If no roles exist yet-->
        <h4>Priskirti leidimą prie rolių</h4>

        @foreach ($roles as $role) 
            {{ Form::checkbox('roles[]',  $role->id ) }}
            {{ Form::label($role->name, ucfirst($role->name)) }}<br>

        @endforeach
    @endif
    <br>
    {{ Form::submit('Išsaugoti', array('class' => 'btn btn-primary')) }}

    {{ Form::close() }}

</div>
</div>
</div>

@endsection