@extends('layouts.app')

@section('content')
 
<div class="container">
    <img src="{{asset('images/backend_images/logo1.png')}}" class="center-block" style="display: block;
    margin-left: auto;
    margin-right: auto;">
        <div class="col-lg-4 col-lg-offset-4">

        <div class="widget-box" style="border-radius: 5px; box-shadow: 1px 2px 1px 0px #888888;">
  
             <div class="widget-content"> 
                <div class="card-header col-lg-4 col-lg-offset-3" ><h3>{{ __('Prisijungimas') }}</h3></div>
               
               
                    <form method="POST" action="{{ route('login') }}">
                        @csrf

                        <div class="form-group row">
                           

                            <div class="col-md-10 col-lg-offset-1">
                                <input id="email" type="email" class="form-control{{ $errors->has('email') ? ' is-invalid' : '' }}" name="email" value="{{ old('email') }}" placeholder="El. paštas" style="border-radius: 5px;"required autofocus>

                                @if ($errors->has('email'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group row">
                

                            <div class="col-md-10 col-lg-offset-1">
                                <input id="password" type="password" class="form-control{{ $errors->has('password') ? ' is-invalid' : '' }}" name="password" placeholder="Slaptažodis" style="border-radius: 5px;" required>

                                @if ($errors->has('password'))
                                    <span class="invalid-feedback">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>
                        <div class="checkbox  col-lg-offset-1">
                                    <label>
                                        <input type="checkbox" name="remember" {{ old('remember') ? 'checked' : '' }}> {{ __('Prisiminti mane') }}
                                    </label>
                                </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-10 col-lg-offset-1">
                                <button type="submit" class="btn btn-primary" style="width: 100%; border-radius: 5px;">
                                    {{ __('Prisijungti') }}
                                </button>

                                <a class="btn btn-link" href="{{ route('password.request') }}">
                                    {{ __('Parmiršai slaptažodį?') }}
                                </a>
                                
                            </div>
                        </div>
                    </form>
                </div>
         
        </div>

     
    </div>
</div>
@endsection
