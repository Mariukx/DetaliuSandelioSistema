@extends('layouts.app')

@section('title', '| Parts')

@section('content')
<style type="text/css">
@media screen and (max-width: 500px){
    .widget-content {
       
        top: 50%;
    left: 50%;
    margin-right: -50%;
    }
}
@media screen and (max-width: 400px){
    img {
       
        top: 50%;
    left: 50%;
    margin-right: -50%;
    }
}

    </style>

<h2 style="text-align: center;">Detalių sąrašas</h2>
 <a class="btn btn-primary btn-sm" href="{{ url('/index') }}" style=" margin-left: 35px"> <h4 style="text-align: left; margin-top: 10px; " >Grįžti atgal į galeriją</h4></a> 
  <div class="container-fluid">
  	<div class="row">
  		<div class="col-lg-3">
  			<div class="widget-box" style="height: auto; margin-left: 20px;">
  		 <div class="widget-content" style="height: auto;  box-shadow: 1px 2px 3px #888888; padding: 10px; width: 100%; background-color: #F0F8FF;">
  		 <h4 style="text-align: center;"><strong>Turite klausimų? </strong></h4>
        <form>
          <div class="form-group">
            <input type="text" class="form-control" name="" value="" placeholder="Vardas">
          </div>
          <div class="form-group">
            <input type="email" class="form-control" name="" value="" placeholder="El. paštas">
          </div>
          <div class="form-group">
            <input type="tel" class="form-control" name="" value="" placeholder="Tel. numeris">
          </div>
          <div class="form-group">
            <textarea class="form-control" name="" rows="3" placeholder="Žinutė"></textarea>
          </div>
          <button class="btn btn-primary" type="submit" name="button">
              <i class="fa fa-paper-plane-o" aria-hidden="true"></i> Išsiųsti
          </button>
        </form>
    </div>
  			</div>
  		</div>
  	
  

   <div class='col-lg-8 col-lg-offset-0' >
    <div class="widget-box" style="height: auto; background-color: #F0F8FF; ">
    	 @foreach($parts as $part) 
    	<div class="widget-content" style="height: auto;   box-shadow: 0px 0.5px 0px 0px #4169E1; padding: 10px; font-size: 18px; ">
                             
                                   			<div class="row">
                                   				<div class="col-sm-3">
                                   				@if(!empty($part->p_image))
					                                      <img src="{{ asset('/images/backend_images/parts/small/'.$part->p_image) }}" style="width:140px; height: 120px; ">
					                                       @else
					                              <img src="{{ asset('/images/backend_images/nopicture.png') }}" style="width:140px; height: 120px; ">
					                                @endif
					                            </div>
                                            <div class="col-sm-3"><b>Pavadinimas</b>: {!! $part -> p_name !!}</div>
                                            <div class="col-sm-3"><b>Kaina</b>: {!! $part -> p_price !!} €</div>
                                            <div class="col-sm-3"><b>Kiekis</b>: {!! $part -> p_quantity !!}</div>
                                            <div class="col-sm-3"><b>Spalva</b>: {!! $part -> p_color !!} </div>
                                            <div class="col-sm-3"><b>Detalės pusė</b>: {!! $part -> p_side !!}</div>
                                            <div class="col-sm-3"><b>Gamintojas</b>: {!! $part -> p_vendor !!}</div>
                                            <div class="col-sm-3"><b>Aprašymas</b>: {!! $part -> p_description !!} </div>
                                             <div class="col-sm-3">  </div>

                                         	 <div class="col-sm-3">          
            								 	<a class="btn btn-primary  " href="#myModal{!! $part -> part_id !!}" data-toggle="modal" >Peržiūrėti</a>
                                             </div>
                                             <div class="row">

                                             </div>
                                             <div class="row">

                                            </div>
                                            <div class="row">
												
            								 </div>
                                            </div>                  
                                           
            							<div id="myModal{!! $part -> part_id !!}" class="modal hide">
                                          <div class="modal-header" style="height: auto;">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h2>{!! $part -> brand !!} {!! $part -> model !!} - {!! $part -> year !!} m. </h2>
                                          </div>

                                          <div class="modal-body">

                                          <h4>  {!! $part -> power !!} kW, {!! $part -> cubature !!} L, {!! $part -> fuel !!}
                                          <!-- <a href="{{url('/inventory/send-order/'.$part -> part_id)}}" class="btn btn-default pull-right">Užsakyti</a></h4>-->

                                            <hr>
                                           <div class="row"> 
	                                           	<div class="col-sm-6"><b>Vairas pusė</b>: {!! $part -> wheel !!}</div>
	                                           	<div class="col-sm-6"><b>Pavarų dėžė</b>: {!! $part -> gearbox !!}</div>
                                           	</div> 
                                           	<div class="row">
                                           			<div class="col-sm-6"><b>Automobilio spalva</b>: {!! $part -> color !!} </div>
                                           			<div class="col-sm-6"><b>Kėbulo tipas</b>: {!! $part -> body_type !!}</div>
                                           	</div> 
                                           	<div class="row">
                                           		<div class="col-sm-6"><b>Rida</b>: {!! $part -> mileage !!} km.</div>
                                           		</div> 
                                            <b>Adresas</b>: {!! $part -> w_address !!}.
                                            <hr>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Pavadinimas</b>: {!! $part -> p_name !!}</div>
                                            <div class="col-sm-6" style="background-color: green; color:  white; font-size: 15px;"><b>Kaina: {!! $part -> p_price !!} € </b></div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Kiekis</b>: {!! $part -> p_quantity !!}</div> 
                                             <div class="col-sm-6"><b>Spalva</b>: {!! $part -> p_color !!} </div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Detalės pusė</b>: {!! $part -> p_side !!}</div>
                                            
                                             <div class="col-sm-6"><b>Gamintojas</b>: {!! $part -> p_vendor !!}</div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Aprašymas</b>: {!! $part -> p_description !!} </div>
                                            <div class="col-sm-6"><b>Detalės kodas</b>: {!! $part -> p_code !!} </div>
                                            </div>
                                             <div class="row">
                                            <div class="col-sm-6"><b>Spalvos kodas</b>: {!! $part -> p_color_code!!} </div>
                                            </div>
                                            <hr>
                                            <div >
                                              @if(!empty($part->p_image))

                                      <img src="{{ asset('/images/backend_images/parts/small/'.$part->p_image) }}" style="width:90%;" >
                                      @else
                                      <img src="{{ asset('/images/backend_images/nopicture.png') }}" style="width:90%; ">
                                    @endif
                                  </div>
                                      </div>
                                    </div>
		               </div>
		                 	@endforeach
		        </div>                          
        </div>
                             
            </div>   

      </div>
@endsection