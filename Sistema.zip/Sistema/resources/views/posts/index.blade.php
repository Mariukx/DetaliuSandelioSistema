@extends('layouts.app')
@section('content')

        <div class="container">
  <h2>Automobilių galerija</h2>
  <h5>Šiuo metu turimi automobiliai ardymui</h5>
 
  @foreach($cars->chunk(4) as $chunk)
  <div class="row">
     @foreach($chunk as $car)
    <div class="col-md-3">
      <div class="thumbnail">
        <a href="#myModal{!! $car -> car_id !!}" data-toggle="modal">
          @if(!empty($car->image))
               <img src="{{ asset('/images/backend_images/cars/small/'.$car->image) }}" style="width:auto; height: 200px;">
               @else
               <img src="{{ asset('/images/backend_images/nopicture.png') }}" style="width:auto; height: 200px;">
          @endif
          <div class="caption" style="background:#F0F8FF; text-align: center;">
            <p><b>{!! $car -> brand !!} {!! $car -> model !!} - {!! $car -> year !!} m.</b></p>
          </div>
        </a>
      </div>
    </div>
     <div id="myModal{!! $car -> car_id !!}" class="modal hide "  >
                                          <div class="modal-header" style="height: auto;">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h2>{!! $car -> brand !!} {!! $car -> model !!} - {!! $car -> year !!} m.</h2>
                                          </div>

                                            <div class="modal-body">
                                            <div class="row">
                                            <div class="col-sm-6"><b>Kuro tipas</b>: {!! $car -> fuel !!}</div>
                                            <div class="col-sm-6"><b>Pavarų dėžės tipas</b>: {!! $car -> gearbox !!}</div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Kubatūra</b>: {!! $car -> cubature !!} L</div>
                                            <div class="col-sm-6"><b>Galia</b>: {!! $car -> power !!} kW</div>
                                          </div>
                                            <div class="row">  
                                            <div class="col-sm-6"><b>Kėbulo tipas</b>: {!! $car -> body_type !!}</div>
                                            <div class="col-sm-6"><b>Spalva</b>: {!! $car -> color !!}</div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Vairo padėtis</b>: {!! $car -> wheel !!}</div>
                                            <div class="col-sm-6"><b>Rida</b>: {!! $car -> mileage !!} km</div>
                                            </div>
                                            <hr>
                                            <a class="btn btn-primary btn-sm" href="{{url('/index/parts-gallery/'.$car -> car_id)}}" style="text-align: center;"><b>Peržiūrėti detalių sąrašą</b></a>
                                            <div >
                                              @if(!empty($car->image))

                                      <img src="{{ asset('/images/backend_images/cars/medium/'.$car->image) }}" style="width: 90%; height: auto;"  content="width=device-width, initial-scale=1.0">
                                      @else
                                      <div>
                              <img src="{{ asset('/images/backend_images/nopicture.png') }}" style="width:90%; "></div>
                                    @endif
                                  </div>
                                      </div>
                                    </div>
        @endforeach
  </div>
  @endforeach
</div>

@endsection






