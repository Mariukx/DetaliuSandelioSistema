@extends('layouts.app')
@section('content')
 
        @if(Session:: has('flash_message_error'))

            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  {!! session('flash_message_error') !!}</strong>
            </div>
             &nbsp;
        @endif

        @if(Session:: has('flash_message_success'))

            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  {!! session('flash_message_success') !!}</strong>
            </div>
             &nbsp;
        @endif
       
      <div class="col-lg-10 col-lg-offset-1">     
            @can('Sukurti detale') <a class="btn btn-success " href="{{ url('/parts/add-parts') }}">Pridėti</a>@endcan &nbsp;
            @can('Atspausdinti PDF')<a class="btn btn-success " href="{{ url('/parts/print-parts') }}">Atspausdinti PDF</a>@endcan
            


                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>Detalių duomenys</h5>
                        </div>
                        <div class="widget-content table-responsive">
                            <table class="table table-bordered  data-table table-responsive" id="example">
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th >Nuotrauka</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                    <th style="width: 15%">Veiksmas</th>
                                   
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                   <th style="width: 5%" >Nr.</th>
                                   <th >Nuotrauka</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                    <th style="width: 15%">Veiksmas</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                @foreach($parts as $part)
                               <tr class="gradeX">
                                   <td>{!! ++$i !!}</td>
                                   <td>
                                    @if(!empty($part->p_image))
                                      <img src="{{ asset('/images/backend_images/parts/small/'.$part->p_image) }}" style="width:100px;">
                                       @else
                              <img src="{{ asset('/images/backend_images/nopicture.png') }}" style="width:100px; ">
                                    @endif
                                  </td>
                                   <td>{!! $part -> car_id !!}</td>
                                   <td>{!! $part -> wh_id !!}</td>
                                   <td>{!! $part -> location_id!!}</td>
                                   <td>{!! $part -> p_name !!}</td>
                                   <td>{!! $part -> p_price !!}</td>
                                   <td>{!! $part -> p_quantity !!}</td>
                                   <td>{!! $part -> p_color !!}</td>
                                   <td>{!! $part -> p_color_code !!}</td>
                                   <td>{!! $part -> p_code !!}</td>
                                   <td>{!! $part -> p_side !!}</td>
                                   <td>{!! $part -> p_vendor !!}</td>
                                   <td>{!! $part -> p_description !!}</td>                                
                                   <td>
                                      @can('Perziureti detale')   <a class="btn  " href="#myModal{!! $part -> part_id !!}" data-toggle="modal" style="color: #4169E1;"><i class="fa fa-eye"></i></a>|
                                       @endcan
                                     @can('Redaguoti detale')  <a class="btn " href="{{ url('/parts/edit-parts/'. $part -> part_id )}}" style="color: green;"><i class="fa fa-edit"></i></a>|@endcan
                                      @can('Istrinti detale')<a id="delPart"  class="btn " href="{{ url('/parts/delete-parts/'. $part -> part_id )}}" style="color: red;"> <i class="fa fa-trash" ></i></a> @endcan
                                   </td>
                               </tr>
                                     <div id="myModal{!! $part -> part_id !!}" class="modal hide">
                                          <div class="modal-header" style="height: auto;">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h2>{!! $part -> brand !!} {!! $part -> model !!} - {!! $part -> year !!} m. </h2>
                                          </div>

                                          <div class="modal-body">
                                            {!! $part -> power !!} kW, {!! $part -> cubature !!} L, {!! $part -> fuel !!}  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;      |  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                            {!! $part -> w_address !!} - {!! $part -> section !!}{!! $part -> stack !!}{!! $part -> shelve !!}{!! $part -> slot !!}
                                            <hr>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Pavadinimas</b>: {!! $part -> p_name !!}</div>
                                            <div class="col-sm-6"><b>Kaina</b>: {!! $part -> p_price !!} €</div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Kiekis</b>: {!! $part -> p_quantity !!}</div> 
                                             <div class="col-sm-6"><b>Spalva</b>: {!! $part -> p_color !!} </div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Detalės pusė</b>: {!! $part -> p_side !!}</div>
                                            
                                             <div class="col-sm-6"><b>Gamintojas</b>: {!! $part -> p_vendor !!}</div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Aprašymas</b>: {!! $part -> p_description !!} </div>
                                            <div class="col-sm-6"><b>Detalės kodas</b>: {!! $part -> p_code !!} </div>
                                            </div>
                                            <div class="row">
                                            
                                            <div class="col-sm-6"><b>Spalvos kodas</b>: {!! $part -> p_color_code !!} </div>
                                            </div>
                                            <hr>
                                            <div >
                                              @if(!empty($part->p_image))

                                      <img src="{{ asset('/images/backend_images/parts/small/'.$part->p_image) }}" style="width: 90%;" >
                                      @else
                                      <img src="{{ asset('/images/backend_images/nopicture.png') }}" style="width:90%; ">
                                    @endif
                                  </div>
                                      </div>
                                    </div>
                                @endforeach
                              </div>
                            </div>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

  
@endsection