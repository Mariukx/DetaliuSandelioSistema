<!Doctype html>
  <html lang="en">
   <head>
    <meta charset="UTF-8">
      <title>Dalys</title>
                <style type="text/css">

                          #parts {
                          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                          }

                          #parts td, #parts th {
                              border: 1px solid #ddd;
                              padding: 8px;
                          }

                          #parts tr:nth-child(even){
                            background-color: #f2f2f2;
                          }

                          #parts tr:hover {
                            background-color: #ddd;
                          }

                          #parts th {
                              padding-top: 12px;
                              padding-bottom: 12px;
                              text-align: left;
                              background-color: #4CAF50;
                              color: white;
                          }
              </style>
   </head>

          <body>

            <h1>Dalys</h1>
                            <table id="parts">
                              
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                  
                                   
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                   <th style="width: 5%" >Nr.</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                    
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                @foreach($parts as $part)
                               <tr class="gradeX">
                                   <td>{!! ++$i !!}</td>
                                   <td>{!! $part -> car_id !!}</td>
                                   <td>{!! $part -> wh_id !!}</td>
                                   <td>{!! $part -> location_id!!}</td>
                                   <td>{!! $part -> p_name !!}</td>
                                   <td>{!! $part -> p_price !!}</td>
                                   <td>{!! $part -> p_quantity !!}</td>
                                   <td>{!! $part -> p_color !!}</td>
                                   <td>{!! $part -> p_color_code !!}</td>
                                   <td>{!! $part -> p_code !!}</td>
                                   <td>{!! $part -> p_side !!}</td>
                                   <td>{!! $part -> p_vendor !!}</td>
                                   <td>{!! $part -> p_description !!}</td>  
                                  
                               </tr>
                                @endforeach
                                </tbody>
                            </table>
       
       
          
          
          </body>
        </html>