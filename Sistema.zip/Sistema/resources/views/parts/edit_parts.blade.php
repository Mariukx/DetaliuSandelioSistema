@extends('layouts.app')

@section('title', '| Parts')

@section('content')
<div class='col-lg-4 col-lg-offset-4'>
    <div class="widget-box">
        <div class="widget-content">
           <h1><i class='fa fa-key'></i> Redaguoti detalę</h1>
    <hr>

    {{ Form::open(array('url' => '/parts/edit-parts/'.$partDetails->part_id,'enctype'=>'multipart/form-data')) }}
                
                                  <!--     <div class="widget-box">
                        <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
                            <h5>Add Cars</h5>
                        </div>

                        <div class="widget-content nopadding">
                            <form class="form-horizontal" method="post" action="{{ url('/admin/add-parts') }}" name="add_cars" id="add_cars" novalidate="novalidate">-->

                        
                                   {{ csrf_field() }}
                            <div class="control-group">
                                  <div class="controls">
                                    {{ Form::label('brand', 'Markė:') }}
                                    {!! Form::select('car_id', $cars,$partDetails->car_id ?: old('car_id'), array('class' => 'form-control') ) !!}
                                </div>
                                </div>

                                  <div class="control-group">
                                 <div class="controls">
                                    {{ Form::label('warehouse', 'Sandėlio adresas:') }}
                                    {!! Form::select('wh_id', $warehouse,$partDetails->wh_id ?: old('wh_id'), array('class' => 'form-control') ) !!}
                                </div>
                                  </div>
                                  <div class="control-group">
                                   
                                    <div class="controls">
                                    {{ Form::label('location', 'Vietos kodas:') }}
                                    {!! Form::select('location_id', $location,$partDetails->location_id ?: old('location_id'), array('class' => 'form-control') ) !!}
                                    </div>
                                  </div>
                                <div class="control-group">
                                    <label class="control-label">Detalės pavadinimas:</label>   
                                    <div class="controls">
                                        <input type="text" class="form-control"  name="p_name" id="p_name" value="{{ $partDetails->p_name}}" required/>
                                    </div>
                                  </div>
                                   <div class="control-group">
                                    <label class="control-label">Kaina:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="10000" step="0.01" name="p_price" id="p_price" value="{{ $partDetails->p_price}}" required/>
                                    </div>
                                  </div>
                                   <div class="control-group">
                                    <label class="control-label">Kiekis:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="200" name="p_quantity" id="p_quantity"  value="{{ $partDetails->p_quantity}}" required/>
                                    </div>
                                  </div>
                                   <div class="control-group">
                                    {{ Form::label('p_color', 'Spalva') }}
                                   {{ Form::select('p_color',['Nėra'=>'Nėra','Balta'=>'Balta','Geltona/aukso'=>'Geltona/aukso','Juoda'=>'Juoda','Mėlyna'=>'Mėlyna','Oranžinė'=>'Oranžinė','Pilka/sidabrinė'=>'Pilka/sidabrinė','Raudona/vyšninė'=>'Raudona/vyšninė','Ruda/smėlio'=>'Ruda/smėlio','Violetinė'=>'Violetinė','Žalia/chaki'=>'Žalia/chaki','Kita'=>'Kita'], $partDetails->p_color ?: old('p_color'), ['class' => 'form-control']) }}
                                  </div>
                                  <div class="control-group">
                                    <label class="control-label">Detalės kodas:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="9999999" name="p_code" id="p_code"  value="{{ $partDetails->p_code}}" required/>
                                    </div>
                                  </div>
                                  <div class="control-group">
                                    <label class="control-label">Spalvos kodas:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="9999999" name="p_color_code" id="p_color_code"  value="{{ $partDetails->p_color_code}}" >
                                    </div>
                                  </div>
                                  <div class="control-group">
                                    <div class="controls">
                                       
                                   {{ Form::label('p_side', 'Detalės pusė') }}
                                   {{ Form::select('p_side',['Nėra'=>'Nėra','Dešinė/Priekis'=>'Dešinė/Priekis', 'Dešinė/Galas'=>'Dešinė/Galas', 'Kairė/Galas'=> 'Kairė/Galas', 'Kairė/Priekis'=>'Kairė/Priekis','Priekis'=> 'Priekis','Galas'=> 'Galas' ], $partDetails->p_side ?: old('p_side'), ['class' => 'form-control']) }}
                                  </div>
                                    </div>
                                 
                                   <div class="control-group">
                                    <div class="controls">
                                     {{ Form::label('p_vendor', 'Gamintojas') }}
                                   {{ Form::select('p_vendor',['Nėra'=>'Nėra','Bosh'=>'Bosh','Dunlop'=>'Dunlop','GoodYear'=> 'GoodYear',  'Kita'=> 'Kita'], $partDetails->p_vendor ?: old('p_vendor'), ['class' => 'form-control']) }}
                                  </div>
                                  </div>
                                  
                                  <div class="control-group">
                                    <label class="control-label">Aprašymas:</label>   
                                    <div class="controls">
                                        <input  type="text" class="form-control" max="255" name="p_description" id="p_description"  value="{{ $partDetails->p_description}}" required/>
                                    </div>
                                  </div>
                                    
                                <div class="control-group">
                                  <label class="control-label">Nuotrauka:</label>
                                  <div class="controls">
                                    <input type="file" class="form-control" name="p_image" id="p_image">
                                    <input type="hidden" name="current_image"  id="current_image" value="{{ $partDetails->p_image}}" accept="image/x-png,image/gif,image/jpeg">
                                    @if(!empty($partDetails->p_image))
                                    <img style="width: 100px;" src="{{ asset('/images/backend_images/parts/small/'.$partDetails->p_image) }}" > <a href="{{url('/parts/delete-parts-image/'.$partDetails->part_id)}}">Panaikinti</a>
                                    @endif
                                  </div>
                                </div>
                                  &nbsp;
                                   <div class='form-group'>
                              @can('Redaguoti detale')  {{ Form::submit('Išsaugoti', array('class' => 'btn btn-primary')) }}@endcan
                                <a href="{{ url()->previous() }}" class="btn btn-primary">Grįžti atgal</a>

                    {{ Form::close() }}
                           
                        </div>
                    </div>
                </div>
        </div>
    </div>

    
    </div>
 
@endsection