{{-- \resources\views\users\index.blade.php --}}
@extends('layouts.app')

@section('title', '| Users')

@section('content')

<div class="col-lg-10 col-lg-offset-1">
   <h1><i class="fa fa-users"></i> Naudotojų administravimas 
       <div> <a href="{{ route('roles.index') }}" class="btn btn-info pull-right">Rolės</a>
    <a href="{{ route('permissions.index') }}" class="btn btn-info pull-right">Leidimai</a></div></h1>
    <hr>
 <div class="widget-box">
        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
             <h5>Naudotojai</h5>
         </div>
    <div class=" widget-content table-responsive">
        <table class="table table-bordered ">

            <thead>
                <tr>
                    <th>Vardas</th>
                    <th>El. Pašas</th>
                    <th>Kada sukurta</th>
                    <th>Naudotojo rolės</th>
                    <th style="width: 17%;">Veiksmas</th>
                </tr>
            </thead>

            <tbody>
                @foreach ($users as $user)
                <tr>

                    <td>{{ $user->name }}</td>
                    <td>{{ $user->email }}</td>
                    <td>{{ $user->created_at->format('Y-m-d H:i:s') }}</td>
                    <td>{{  $user->roles()->pluck('name')->implode(' ') }}</td>{{-- Retrieve array of roles associated to a user and convert to string --}}
                    <td>
                    <a href="{{ route('users.edit', $user->id) }}" class="btn btn-info pull-left" >Redaguoti</a>

                    {!! Form::open(['method' => 'DELETE', 'route' => ['users.destroy', $user->id] ]) !!}
                    {!! Form::submit('Ištrinti', ['class' => 'btn btn-danger']) !!}
                    {!! Form::close() !!}

                    </td>
                </tr>
                @endforeach

                

            </tbody>

        </table>
    </div>
</div>

    <a href="{{ route('users.create') }}" class="btn btn-success">Pridėti naudotoją</a>

</div>

@endsection