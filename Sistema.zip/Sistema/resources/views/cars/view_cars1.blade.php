@extends('layouts.app')

@section('title', '| Car parts')

@section('content')


 @if(Session:: has('flash_message_error'))

            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  {!! session('flash_message_error') !!}</strong>
            </div>
              &nbsp;
        @endif

        @if(Session:: has('flash_message_success'))

            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  {!! session('flash_message_success') !!}</strong>
            </div>
              &nbsp;
        @endif
      &nbsp;
       <div class="col-lg-10 col-lg-offset-1">     
            @can('Sukurti auto') <a class="btn btn-success " href="{{ url('/cars/add-cars') }}">Pridėti</a>@endcan &nbsp;
             @can('Atspausdinti PDF')<a class="btn btn-success " href="{{ url('/cars/print-cars') }}">Atspausdinti PDF</a>@endcan
      <form enctype="multipart/form-data" class="form-horizontal" method="get" action="{{ url('/cars/view-cars1') }}" name="add_product" id="add_product" novalidate="novalidate"> 
            <div class="widget-box">
                <div class="control-group">{{ csrf_field() }}
                                    <label class="control-label">Markė:</label>
                                    <div class="controls">
                                    
                                        <select required aria-required="true"  class="form-control" id="brand" name="brand" onchange="fillSelect(this.value,this.form['model'])">
                                         <option selected value="">Pasirinkite:</option>
                                          <option value="Honda">Honda</option>
                                          <option value="Hyundai">Hyundai</option>
                                          <option value="Kia">Kia</option>
                                          <option value="Lexus">Lexus</option>
                                          <option value="Mazda">Mazda</option>
                                          <option value="Mitshubishi">Mitsubishi</option>
                                          <option value="Nissan">Nissan</option>
                                          <option value="Subaru">Subaru</option>
                                          <option value="Suzuki">Suzuki</option>
                                          <option value="Toyota">Toyota</option>
                                        </select>
                                    </div>
                                </div>

                                 <div class="control-group">
                                    <label class="control-label">Modelis:</label>
                                    <div class="controls">
                                       
                                         <select required aria-required="true"  class="form-control" id="model" name="model" >
                                            <option selected value="">Pasirinkite:</option>
                     
                                         </select>
                                    </div>
                                </div>
            </div>
<div class="form-actions">
                <input type="submit" value="Add Product" class="btn btn-success">
              </div>
            </form>
                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>Automobilių duomenys</h5>
                        </div>
                        <div class="widget-content table-responsive ">
                            <table class="table table-bordered  data-table table-responsive" id="example">
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th >Nuotrauka</th>
                                    <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                  <th style="width: 15%">Veiksmas</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                   <th >Nuotrauka</th>
                                      <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                  <th style="width: 15%">Veiksmas</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                 @foreach($cars as $car)
                                 <tr class="gradeX">
                                 <td>{!! $car -> brand !!}</td>
                                 <td>{!! $car -> model !!}</td>
                                 <td>{!! $car -> year !!}</td>
                               </tr>
                                 @endforeach
                                
                                </tbody>
                            </table>
                        </div>
                    </div>

                    
                                
                               
                </div>
            </div>
        </div>
    </div>
   <script type="text/javascript">
  
  var model = []; 
  model["Honda"] = ["Accord", "Civic","Civic Type R","CR-V","CRX","Element", "FR-V","Insight","Odissey","Prelude","S2000"];
  model["Hyundai"] = ["Accent", "Coupe", "Getz", "i30"];
  model["Kia"] = ["Cee'd","Optima","Picanto", "Rio", "Sorento"];
  model["Lexus"] = ["ES 200","ES 240","ES 250","ES 300","IS 200","IS 250","IS 300","IS 350","GS 300","HS 250h"];
  model["Mazda"] = ["121", "2","3","323","323F","5","6","626","MX-5","RX-8","Premacy","Xedos 9"];
  model["Mitshubishi"] = ["Carisma","Colt","Eclipse","Galant","Lancer","Lancer Evolution","Pajero","SpaceStar"];
  model["Nissan"] = ["Almera","Altima","Juke","Leaf","Micra","Murano","Note","Tino","Xtrail"];
  model["Subaru"] = ["Forester","Impreza","Legacy","Outback","WRX"];
  model["Suzuki"] = ["Alto","Grand Vitara","Liana","Swift","SX 4"];
  model["Toyota"] = ["Aygo","Avensis","Auris","Camry","Corrola","Corrola Verso","Highlander","Yaris","Land Cruiser","Previa","Prius","RAV4","Verso"];
  
  function fillSelect(nValue,nList){

    nList.options.length = 1;
    var curr = model[nValue];
    for (each in curr)
      {
       var nOption = document.createElement('option'); 
       nOption.appendChild(document.createTextNode(curr[each])); 
       nOption.setAttribute("value",curr[each]);       
       nList.appendChild(nOption); 
      }
  }

</script>
    @endsection