<!Doctype html>
  <html lang="en">
   <head>
    <meta charset="UTF-8">
      <title>Cars</title>
                <style type="text/css">

                          #cars {
                          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                          }

                          #cars td, #cars th {
                              border: 1px solid #ddd;
                              padding: 8px;
                          }

                          #cars tr:nth-child(even){
                            background-color: #f2f2f2;
                          }

                          #cars tr:hover {
                            background-color: #ddd;
                          }

                          #cars th {
                              padding-top: 12px;
                              padding-bottom: 12px;
                              text-align: left;
                              background-color: #4CAF50;
                              color: white;
                          }
              </style>
   </head>

          <body>

            <h1>Automobiliai</h1>
                            <table id="cars">
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    
                                    <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                 
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                   
                                      <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                  
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                @foreach($cars as $car)
                               <tr>
                                   <td>{!! ++$i !!}</td>
                                 
                                   <td>{!! $car -> brand !!}</td>
                                   <td>{!! $car -> model !!}</td>
                                   <td>{!! $car -> year !!}</td>
                                   <td>{!! $car -> fuel !!}</td>
                                   <td>{!! $car -> gearbox !!}</td>
                                   <td>{!! $car -> cubature !!}</td>
                                   <td>{!! $car -> power !!}</td>
                                   <td>{!! $car -> body_type !!}</td>
                                   <td>{!! $car -> color !!}</td>
                                   <td>{!! $car -> wheel !!}</td>
                                   <td>{!! $car -> mileage !!}</td>
                                  
                               </tr>
                                @endforeach
                                </tbody>
                            </table>
       
       
          
          
          </body>
        </html>