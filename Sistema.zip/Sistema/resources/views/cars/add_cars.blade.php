@extends('layouts.app')

@section('title', '| Car parts')

@section('content')
<style type="text/css">
@media screen and (max-width: 400px){
    .form-control, .control-group{
        width: 60%;
        
        
    }
}
@media screen and (max-width: 500px){
    .form-control, .control-group{
        width: 60%;
        
        
    }
}
@media screen and (max-width: 700px){
    .form-control{
        width: 60%;
        
        
    }
}
@media screen and (max-width: 400px){
    .widget-box, .widget-content{
        width: 90%;
        
        
    }
}
@media screen and (max-width: 700px){
    .widget-box, .widget-content{
        width: 90%;
        
        
    }
}
</style>
<div class='col-lg-4 col-lg-offset-4'>
    <div class="widget-box">
        <div class="widget-content">
           <h1><i class='fa fa-key'></i> Pridėti automobilį</h1>
    <hr>

    {{ Form::open(array('url' => 'cars/add-cars', 'enctype'=>'multipart/form-data')) }}

  <!--  <div class="form-group">
        {{ Form::label('brand', 'Markė') }}
        {{ Form::text('brand', null, array('class' => 'form-control')) }}
    </div>
     <div class="form-group">
        {{ Form::label('model', 'Modelis') }}
        {{ Form::text('model', null, array('class' => 'form-control')) }}
    </div>-->
    <div class="control-group">{{ csrf_field() }}
                                    <label class="control-label">Markė:</label>
                                    <div class="controls">
                                    
                                        <select required aria-required="true"  class="form-control" id="brand" name="brand" onchange="fillSelect(this.value,this.form['model'])">
                                         <option selected value="">Pasirinkite:</option>
                                          <option value="Honda">Honda</option>
                                          <option value="Hyundai">Hyundai</option>
                                          <option value="Kia">Kia</option>
                                          <option value="Lexus">Lexus</option>
                                          <option value="Mazda">Mazda</option>
                                          <option value="Mitshubishi">Mitsubishi</option>
                                          <option value="Nissan">Nissan</option>
                                          <option value="Subaru">Subaru</option>
                                          <option value="Suzuki">Suzuki</option>
                                          <option value="Toyota">Toyota</option>
                                        </select>
                                    </div>
                                </div>

   <div class="control-group">
                                    <label class="control-label">Modelis:</label>
                                    <div class="controls">
                                       
                                         <select required aria-required="true"  class="form-control" id="model" name="model" >
                                            <option selected value="">Pasirinkite:</option>
                     
                                         </select>
                                    </div>
                                </div>

<div class="control-group" >
                                    <label class="control-label">Metai:</label>
                                    <div class="controls">
                                         <select required aria-required="true"   class="form-control " id="year" name="year" >
                                          <option selected value="">Pasirinkite:</option>
                                          <option>2018</option>
                                          <option>2017</option>
                                          <option>2016</option>
                                          <option>2015</option>
                                          <option>2014</option>
                                          <option>2013</option>
                                          <option>2012</option>
                                          <option>2011</option>
                                          <option>2010</option>
                                          <option>2009</option>
                                          <option>2008</option>
                                          <option>2007</option>
                                          <option>2006</option>
                                          <option>2005</option>
                                          <option>2004</option>
                                          <option>2003</option>
                                          <option>2002</option>
                                          <option>2001</option>
                                          <option>2000</option>
                                          <option>1999</option>
                                          <option>1998</option>
                                          <option>1997</option>
                                          <option>1996</option>
                                          <option>1995</option>
                                          <option>1994</option>
                                        </select>
                                    </div>
                                </div>
                            
                                 <div class="control-group">
                                    <label class="control-label">Degalų tipas:</label>
                                    <div class="controls">
                                         <select required aria-required="true"   class="form-control" id="fuel" name="fuel" >
                                          <option value="">Pasirinkite:</option>
                                          <option >Benzinas</option>
                                          <option >Benzinas/dujos</option>
                                          <option >Dyzelis</option>
                                          <option >Eletra</option>
                                          <option >Hibridas</option>
                                         </select>
                                    </div>
                                </div>
                          

                         
                                 <div class="control-group">
                                    <label class="control-label">Pavarų dėžės tipas:</label>
                                    <div class="controls">
                                       <select required aria-required="true"   class="form-control" id="gearbox" name="gearbox" >
                                          <option value="">Pasirinkite:</option>
                                          <option value="A">Automatinė</option>
                                          <option value="M">Mechaninė</option>
                                         </select>                                    
                                     </div>
                                </div>
                                 <div class="control-group">
                                    <label class="control-label">Kubatūra:</label>
                                    <div class="controls">
                                        <select required aria-required="true"   class="form-control " id="cubature" name="cubature" >
                                          <option selected value="">Pasirinkite:</option>
                                          <option>1.0</option>
                                          <option>1.1</option>
                                          <option>1.2</option>
                                          <option>1.3</option>
                                          <option>1.4</option>
                                          <option>1.5</option>
                                          <option>1.6</option>
                                          <option>1.7</option>
                                          <option>1.8</option>
                                          <option>1.9</option>
                                          <option>2.0</option>
                                          <option>2.1</option>
                                          <option>2.2</option>
                                          <option>2.3</option>
                                          <option>2.4</option>
                                          <option>2.5</option>
                                          <option>2.6</option>
                                          <option>2.7</option>
                                          <option>2.8</option>
                                          <option>2.9</option>
                                          <option>3.0</option>
                                          <option>3.1</option>
                                          <option>3.2</option>
                                          <option>3.3</option>
                                          <option>3.4</option>
                                          <option>3.5</option>
                                        </select>
                                    </div>
                                </div>
                            
                                 <div class="control-group">
                                    <label class="control-label">Galia:</label>
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="300" name="power" id="power" placeholder="Įrašykite" required/>
                                    </div>
                                </div>
                                <div class="control-group">
                                    <label class="control-label">Kėbulo tipas:</label>
                                    <select required aria-required="true"   class="form-control" id="body_type" name="body_type" >
                                          <option value="">Pasirinkite:</option>
                                          <option value="Sedanas">Sedanas</option>
                                          <option value="Hečbekas">Hečbekas</option>
                                          <option value="Universalas">Universalas</option>
                                          <option value="Vienatūris">Vienatūris</option>
                                          <option value="Visureigis">Visureigis</option>
                                          <option value="Kupė">Kupė</option>
                                          <option value="Komercinis">Komercinis</option>
                                          <option value="Kabrioletas">Kabrioletas</option>
                                          <option value="Limuzinas">Limuzinas</option>
                                          <option value="Pikapas">Pikapas</option>
                                          <option value="Kita">Kita</option>
                                         </select>                                    
                                     </div>
                               
                                <div class="control-group">
                                    <label class="control-label">Spalva:</label>
                                    <select required aria-required="true"   class="form-control" id="color" name="color" >
                                          <option value="">Pasirinkite:</option>
                                          <option value="Balta">Balta</option>
                                          <option value="Geltona/aukso">Geltona/aukso</option>
                                          <option value="Juoda">Juoda</option>
                                          <option value="Mėlyna">Mėlyna</option>
                                          <option value="Oranžinė">Oranžinė</option>
                                          <option value="Pilka/sidabrinė">Pilka/sidabrinė</option>
                                          <option value="Raudona/vyšninė">Raudona/vyšninė</option>
                                          <option value="Ruda/">Ruda/smėlio</option>
                                          <option value="Violetinė">Violetinė</option>
                                          <option value="Žalia/chaki">Žalia/chaki</option>
                                          <option value="Kita">Kita</option>
                                         </select>                                    
                                     </div>
                              
                                <div class="control-group">
                                    <label class="control-label">Vairo padėtis:</label>
                                    <select required aria-required="true"   class="form-control" id="wheel" name="wheel" >
                                          <option value="">Pasirinkite:</option>
                                          <option value="D">Dešinėje</option>
                                          <option value="K">Kairėje</option>
                                         </select>                                    
                                     </div>
                                
                                <div class="control-group">
                                    <label class="control-label">Rida:</label>
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="1000000" name="mileage" id="mileage" placeholder="Įrašykite" required/>
                                    </div>
                                </div>
                                <div class="control-group">
                                  <label class="control-label">Nuotrauka:</label>
                                  <div class="controls">
                                    <input type="file" class="form-control" name="image" id="image" accept="image/x-png,image/gif,image/jpeg">
                                  </div>
                                </div>
                           &nbsp;
    <div class='form-group'>
 
  @can('Sukurti auto')  {{ Form::submit('Išsaugoti', array('class' => 'btn btn-primary')) }}@endcan
    <a href="{{ url()->previous() }}" class="btn btn-primary">Grįžti atgal</a>
    {{ Form::close() }}
</div>
</div>
</div>

    
    </div>
    <script type="text/javascript">
  
  var model = []; 
  model["Honda"] = ["Accord (CC/CD/CE/CF) SDN (EU), 10.95-10.98", "Accord (CC7) (EU) SDN, 03.93-09.95" ,"Accord (CD7/CE1) SDN (USA) 01.93-//AERODECK/coupe 95-/-12.98","Accord (CF/CG/CH/CL) SDN (EU), 11.98-12.02","Accord (CG) (USA), 01.98-12.02","Accord (CU2), 03.08-03.11", "Accord (CU2), 04.11-",
  "Civic (EP/EU/EV) 3/5-D HB (EU), 02.01-12.03", "Civic (FA) SDN (USA), 05.06-09.11","Civic (FB) EU/US SDN/COUPE, 09.11-","CIVIC (MA_/MB1) LB 5-D (EU), 01.95-12.96","CIVIC (MB_/MC2) LB 5-D/kombi(EU), 01.97-.04.01","CIVIC 3-D (EJ/EK) HB/SDN (JP), 01.99-07.01","CIVIC 3-D (EJ/EK) HB/SDN (JP), 10.95-12.98","CIVIC 4-D (ES) SDN (JP), 02.01-12.03","CIVIC CRX (ED9/EE8), 10.87-05.92","CIVIC CRX (EH6/EG2), 06.92-12.98",
  "Civic Type R","CRV (RD), 01.02-12.04","CRV (RD), 01.05-10.06","CRV (RD), 10.95-12.01","CRV (RE), 09.06-11.09","CRV (RE), 11.09-12.12",
  "ELEMENT, 07.02-12.11", "FRV (BE), 02.05-09.09","INSIGHT (ZE1), 12.99-12.05","INSIGHT (ZE2), 01.09-","JAZZ/FIT (GD), 03.02-10.08","JAZZ/FIT (GE), 10.08-01.11","JAZZ/FIT (GE), 01.11-12.15","ODYSSEY (RL3), 01.05-01.08","PRELUDE (BB), 01.92-08.96","PRELUDE (BB), 10.96-12.01","S2000 (AP), 04.99-06.09"];
  model["Hyundai"] = ["Accent", "Coupe", "Getz", "i30"];
  model["Kia"] = ["Cee'd","Optima","Picanto", "Rio", "Sorento"];
  model["Lexus"] = ["ES 200","ES 240","ES 250","ES 300","IS 200","IS 250","IS 300","IS 350","GS 300","HS 250h"];
  model["Mazda"] = ["121 (JASM/JBSM), 01.00-12.02","121 (JASM/JBSM), 03.96-12.99", "2 (DE), 10.10-10.14", "2 (DE), 11.07-10.10", "2 (DJ), 07.14-","3 (BK), 10.03-07.09","3 (BL), 07.09-10.11","3 (BL), 10.11-09.13","3 (BM), 06.13-","323 (BG), 01.90-05.94","323 (BH), 08.94-12.98","323 (BJ), 01.01-09.03","323 (BJ), 07.98-12.00","323 P (BA), 10.96-12.00","323F (BA), 08.94-08.98","323F (BG), 01.89-07.94","323F (BJ), 01.01-09.03","323F (BJ), 09.98-12.00","5 (CR19), 04.05-05.10","5 (CR19), 05.10-","6 (GG/GY), 06.02-11.07","6 (GH), 11.07-12.12","6 (GJ), 11.12-","6 USA (GH), 08-","626","MX-5 (NA), 09.89-04.98","MX-5 (NB), 05.98-03.05","MX-5 (NC), 03.05-","RX-8 (SE3P), 09.03-06.12","PREMACY (CP), 01.99-12.04","XEDOS 6/MILLENIA (CA), 05.92-01.99","XEDOS 9/MILLENIA (TA), 07.93-09.02"];
  model["Mitshubishi"] = ["Carisma","Colt","Eclipse","Galant","Lancer","Lancer Evolution","Pajero","SpaceStar"];
  model["Nissan"] = ["Almera","Altima","Juke","Leaf","Micra","Murano","Note","Tino","Xtrail"];
  model["Subaru"] = ["Forester","Impreza","Legacy","Outback","WRX"];
  model["Suzuki"] = ["Alto","Grand Vitara","Liana","Swift","SX 4"];
  model["Toyota"] = ["Aygo","Avensis","Auris","Camry","Corrola","Corrola Verso","Highlander","Yaris","Land Cruiser","Previa","Prius","RAV4","Verso"];
  
  function fillSelect(nValue,nList){

    nList.options.length = 1;
    var curr = model[nValue];
    for (each in curr)
      {
       var nOption = document.createElement('option'); 
       nOption.appendChild(document.createTextNode(curr[each])); 
       nOption.setAttribute("value",curr[each]);       
       nList.appendChild(nOption); 
      }
  }

</script>
@endsection