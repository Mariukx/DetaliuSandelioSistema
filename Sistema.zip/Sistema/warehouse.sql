﻿/*
Navicat MySQL Data Transfer

Source Server         : phpMyAdmin DB's
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : warehouse

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2018-05-31 13:54:07
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cars
-- ----------------------------
DROP TABLE IF EXISTS `cars`;
CREATE TABLE `cars` (
  `car_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Automobilio ID',
  `car_info_id` int(10) unsigned DEFAULT NULL COMMENT 'Automobilio papildomos informacijos ID',
  `brand` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Automobilio markė',
  `model` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Automobilio modelis',
  `year` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio pagaminimo metai',
  `fuel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio kuro tipas',
  `gearbox` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio pavarų dėžės tipas',
  `cubature` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio variklio kubatūra',
  `power` varchar(4) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio variklio galingumas',
  `wheel` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio vairo padėtis',
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio spalva',
  `color_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio spalvos kodai',
  `body_type` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Automobilio kėbulo tipas',
  `mileage` int(6) DEFAULT NULL COMMENT 'Automobilio rida',
  `image` blob COMMENT 'Automobilio nuotrauka',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Atnaujinimo data',
  PRIMARY KEY (`car_id`),
  KEY `brand` (`brand`(191)),
  KEY `car_info_id` (`car_info_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for car_info
-- ----------------------------
DROP TABLE IF EXISTS `car_info`;
CREATE TABLE `car_info` (
  `car_info_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Automobilio papildomos informacijos ID',
  `c_price` decimal(10,2) DEFAULT NULL COMMENT 'Automobilio kaina',
  `c_quantity` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Automobilių kiekis',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Atnaujinimo data',
  PRIMARY KEY (`car_info_id`),
  CONSTRAINT `car_info_ibfk_1` FOREIGN KEY (`car_info_id`) REFERENCES `cars` (`car_info_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_lithuanian_ci;

-- ----------------------------
-- Table structure for categories
-- ----------------------------
DROP TABLE IF EXISTS `categories`;
CREATE TABLE `categories` (
  `category_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Kategorijos ID',
  `category_name` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Detalių kategorijos pavadinimas',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Atnaujinimo data',
  PRIMARY KEY (`category_id`),
  CONSTRAINT `categories_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `parts` (`category_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_lithuanian_ci;

-- ----------------------------
-- Table structure for locations
-- ----------------------------
DROP TABLE IF EXISTS `locations`;
CREATE TABLE `locations` (
  `location_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Vietos ID',
  `wh_id` int(10) unsigned NOT NULL COMMENT 'Sandėlio ID',
  `section` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Sekcijos numeris',
  `stack` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Stelažo numeris',
  `shelve` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Lentynos numeris',
  `slot` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Nustatytos vietos numeris',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Atnaujimo data',
  PRIMARY KEY (`location_id`),
  KEY `wh_id` (`wh_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8 COLLATE=utf8_lithuanian_ci;

-- ----------------------------
-- Table structure for migrations
-- ----------------------------
DROP TABLE IF EXISTS `migrations`;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for model_has_permissions
-- ----------------------------
DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_lithuanian_ci;

-- ----------------------------
-- Table structure for model_has_roles
-- ----------------------------
DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL COMMENT 'Rolės ID',
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Modelio tipas',
  `model_id` bigint(20) unsigned NOT NULL COMMENT 'Naudotojo ID',
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_lithuanian_ci;

-- ----------------------------
-- Table structure for parts
-- ----------------------------
DROP TABLE IF EXISTS `parts`;
CREATE TABLE `parts` (
  `part_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Detalės ID',
  `car_id` int(10) unsigned NOT NULL COMMENT 'Automobilio ID',
  `wh_id` int(10) unsigned NOT NULL COMMENT 'Sandėlio ID',
  `location_id` int(10) unsigned DEFAULT NULL COMMENT 'Vietos ID',
  `category_id` int(10) unsigned DEFAULT NULL COMMENT 'Kategorijos ID',
  `p_name` varchar(255) COLLATE utf8_lithuanian_ci NOT NULL COMMENT 'Detalės pavadinimas',
  `p_color` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Detalės spalva',
  `p_code` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Detalės gamyklinis kodas',
  `p_color_code` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Detalės spalvos kodas',
  `p_side` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Detalės pusės pavadinimas',
  `p_vendor` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Detalės gamintojas',
  `p_image` blob COMMENT 'Detalės nuotrauka',
  `p_price` decimal(10,2) DEFAULT NULL COMMENT 'Detalės kaina',
  `p_quantity` int(10) DEFAULT NULL COMMENT 'Detalės kiekis',
  `p_description` varchar(255) COLLATE utf8_lithuanian_ci DEFAULT NULL COMMENT 'Detalės aprašymas/pastabos',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Atnaujinimo data',
  PRIMARY KEY (`part_id`),
  KEY `id` (`car_id`),
  KEY `wh_id` (`wh_id`),
  KEY `parts_ibfk_3` (`location_id`),
  KEY `category_id` (`category_id`),
  CONSTRAINT `parts_ibfk_1` FOREIGN KEY (`car_id`) REFERENCES `cars` (`car_id`) ON DELETE CASCADE,
  CONSTRAINT `parts_ibfk_2` FOREIGN KEY (`wh_id`) REFERENCES `warehouses` (`wh_id`) ON DELETE CASCADE,
  CONSTRAINT `parts_ibfk_3` FOREIGN KEY (`location_id`) REFERENCES `locations` (`location_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8 COLLATE=utf8_lithuanian_ci;

-- ----------------------------
-- Table structure for password_resets
-- ----------------------------
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------
-- Table structure for permissions
-- ----------------------------
DROP TABLE IF EXISTS `permissions`;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Leidimo ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Leidimo pavadinimas',
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Naudotojų autentifikacijos tipo pavadinimas',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Atnaujinimo data',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_lithuanian_ci;


-- ----------------------------
-- Table structure for roles
-- ----------------------------
DROP TABLE IF EXISTS `roles`;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Rolės ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Rolės pavadinimas',
  `guard_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Naudotojų autentifikacijos tipo pavadinimas',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Atnaujinimo data',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_lithuanian_ci;

-- ----------------------------
-- Table structure for role_has_permissions
-- ----------------------------
DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL COMMENT 'Leidimo ID',
  `role_id` int(10) unsigned NOT NULL COMMENT 'Rolės ID',
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_lithuanian_ci;

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Naudotojo ID',
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Naudotojo vardas',
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Naudotojo el.paštas',
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Naudotojo slaptažodis',
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Žymė, skirta naudotojų sesijoms atsiminti',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Sukūrimo data',
  `updated_at` timestamp NULL DEFAULT NULL COMMENT 'Atnaujinimo data',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_lithuanian_ci;

-- ----------------------------
-- Table structure for warehouses
-- ----------------------------
DROP TABLE IF EXISTS `warehouses`;
CREATE TABLE `warehouses` (
  `wh_id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'Sandėlio ID',
  `w_address` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'Sandėlio adresas',
  `created_at` timestamp NULL DEFAULT NULL COMMENT 'Atnaujinimo data',
  `updated_at` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT 'Sukūrimo data',
  PRIMARY KEY (`wh_id`),
  KEY `wh_id` (`wh_id`) USING BTREE,
  CONSTRAINT `warehouses_ibfk_1` FOREIGN KEY (`wh_id`) REFERENCES `locations` (`wh_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
