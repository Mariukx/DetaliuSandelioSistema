<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/*Route::get('/', function () {
    return view('welcome');
});
*/
Route::get('/', 'HomeController@mainPage');
Route::get('/', 'PostController@viewHomeCars');
Route::get('/index', 'PostController@index')->name('home');
Route::get('/index', 'PostController@viewCars');
Route::get('/index/parts-gallery/{car_id}','PostController@partsGallery');

Auth::routes();

Route::group(['middleware' => ['auth']], function(){
Route::get('/inventory/carparts','PartsController@viewCarParts');
Route::get('/inventory/print-carparts','CarsController@pdf1');
Route::get('/inventory/send-order/{part_id}','PartsController@Order');
Route::get('/inventory/carparts1','SearchController@filterCarParts');
//cars
Route::get('/cars/view-cars','CarsController@viewCars');
Route::get('/cars/view-cars1','SearchController@filterCars');
Route::match(['get','post'],'/cars/add-cars','CarsController@addCars');
Route::match(['get','post'],'/cars/delete-cars/{car_id}','CarsController@deleteCars');
Route::match(['get','post'],'/cars/edit-cars/{car_id}', 'CarsController@editCars');
Route::get('/cars/print-cars','CarsController@pdf');
Route::get('/cars/delete-cars-image/{car_id}', 'CarsController@deleteCarImage');

//parts
Route::get('/parts/view-parts','PartsController@viewParts');
Route::match(['get','post'],'/parts/add-parts','PartsController@addParts');
Route::match(['get','post'],'/parts/edit-parts/{id}', 'PartsController@editParts');
Route::match(['get','post'],'/parts/delete-parts/{id}','PartsController@deleteParts');
Route::get('/parts/print-parts','PartsController@pdf');
Route::get('/parts/delete-parts-image/{part_id}', 'PartsController@deletePartImage');

Route::resource('users', 'UserController');

Route::resource('roles', 'RoleController');

Route::resource('permissions', 'PermissionController');

Route::resource('posts', 'PostController');

});
