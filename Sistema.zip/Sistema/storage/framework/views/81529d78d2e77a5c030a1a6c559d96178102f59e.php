<?php $__env->startSection('title', '| Parts'); ?>

<?php $__env->startSection('content'); ?>

<div class="container-fluid">
	
	<div class="col-lg-3 col-lg-offset-1">
		<div class="widget-box">
		<div class="widget-content">
     <form>

	<div class="form-group"> <!-- Full Name -->
		<label for="full_name_id" class="control-label">Vardas, Pavardė</label>
		<input type="text" class="form-control" id="full_name_id" name="full_name" placeholder="Vardenis Pavardenis">
	</div>	

	<div class="form-group"> <!-- Street 1 -->
		<label for="street1_id" class="control-label">Adresas 1</label>
		<input type="text" class="form-control" id="street1_id" name="street1" placeholder="Gatvė, namo numeris">
	</div>					
							
	<div class="form-group"> <!-- Street 2 -->
		<label for="street2_id" class="control-label">Adresas 2</label>
		<input type="text" class="form-control" id="street2_id" name="street2" placeholder="Gatvė, namo numeris">
	</div>	

	<div class="form-group"> <!-- City-->
		<label for="city_id" class="control-label">Miestas</label>
		<input type="text" class="form-control" id="city_id" name="city" placeholder="Vilnius">
	</div>									
							
	<div class="form-group"> <!-- State Button -->
		<label for="state_id" class="control-label">Savivaldybė</label>
		<select class="form-control" id="state_id">
			<option value="AL">Vilniaus</option>
			<option value="AL">Alabama</option>
			<option value="AK">Alaska</option>
			<option value="AZ">Arizona</option>
			<option value="AR">Arkansas</option>
			<option value="CA">California</option>
			<option value="CO">Colorado</option>
			<option value="CT">Connecticut</option>
			<option value="DE">Delaware</option>
			<option value="DC">District Of Columbia</option>
			<option value="FL">Florida</option>
			<option value="GA">Georgia</option>
			<option value="HI">Hawaii</option>
			<option value="ID">Idaho</option>
			<option value="IL">Illinois</option>
			<option value="IN">Indiana</option>
			<option value="IA">Iowa</option>
			<option value="KS">Kansas</option>
			<option value="KY">Kentucky</option>
			<option value="LA">Louisiana</option>
			<option value="ME">Maine</option>
			<option value="MD">Maryland</option>
			<option value="MA">Massachusetts</option>
			<option value="MI">Michigan</option>
			<option value="MN">Minnesota</option>
			<option value="MS">Mississippi</option>
			<option value="MO">Missouri</option>
			<option value="MT">Montana</option>
			<option value="NE">Nebraska</option>
			<option value="NV">Nevada</option>
			<option value="NH">New Hampshire</option>
			<option value="NJ">New Jersey</option>
			<option value="NM">New Mexico</option>
			<option value="NY">New York</option>
			<option value="NC">North Carolina</option>
			<option value="ND">North Dakota</option>
			<option value="OH">Ohio</option>
			<option value="OK">Oklahoma</option>
			<option value="OR">Oregon</option>
			<option value="PA">Pennsylvania</option>
			<option value="RI">Rhode Island</option>
			<option value="SC">South Carolina</option>
			<option value="SD">South Dakota</option>
			<option value="TN">Tennessee</option>
			<option value="TX">Texas</option>
			<option value="UT">Utah</option>
			<option value="VT">Vermont</option>
			<option value="VA">Virginia</option>
			<option value="WA">Washington</option>
			<option value="WV">West Virginia</option>
			<option value="WI">Wisconsin</option>
			<option value="WY">Wyoming</option>
		</select>					
	</div>
	
	<div class="form-group"> <!-- Zip Code-->
		<label for="zip_id" class="control-label">Pašto kodas</label>
		<input type="text" class="form-control" id="zip_id" name="zip" placeholder="#####">
	</div>		
	
	<div class="form-group"> <!-- Submit Button -->
		<button type="submit" class="btn btn-primary">Užsakyti!</button>
	</div>     
	
</form>	
</div>
</div>
</div>
<div class="col-lg-7 col-lg-offset-0">
	<div class="widget-box">
		<div class="widget-content">
		<h2 style="text-align: center;">Jūsų užsakymas</h2>
		<hr>
		 <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
		<h5><?php echo $part -> brand; ?> <?php echo $part -> model; ?> <?php echo $part -> year; ?> m. - <?php echo $part -> p_name; ?>    x1</h5>
		<hr>
		<div style="background-color: #5bc0de; width: 100px; height: 50px; color: white; font-size: 20px; margin:right; ">Kaina: <b><?php echo $part -> p_price; ?> €</b></div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<hr>
		</div>
	</div>
	</div>
	
</div>
-
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>