<?php $__env->startSection('title', '| Car parts'); ?>

<?php $__env->startSection('content'); ?>


 <?php if(Session:: has('flash_message_error')): ?>

            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  <?php echo session('flash_message_error'); ?></strong>
            </div>
              &nbsp;
        <?php endif; ?>

        <?php if(Session:: has('flash_message_success')): ?>

            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  <?php echo session('flash_message_success'); ?></strong>
            </div>
              &nbsp;
        <?php endif; ?>
      &nbsp;
      <div class="col-lg-10 col-lg-offset-1 "  >
        <div class="widget-box" > 
          <div class="widget-content" style="box-shadow: 2px 3px 2px 0px grey; background-color: #F0F8FF">
        <form enctype="multipart/form-data" class="form-horizontal" method="get" action="<?php echo e(url('/cars/view-cars1')); ?>" name="add_product" id="add_product" novalidate="novalidate"> 
            
              <div class="row">
                <div class="control-group col-xs-6 mb-3" ><?php echo e(csrf_field()); ?>

                                    
                                    <div class="controls" >
                                    
                                        <select required aria-required="true"  class="form-control" id="brand" name="brand" onchange="fillSelect(this.value,this.form['model'])">
                                         <option selected value="">Markė:</option>
                                          <option value="Honda">Honda</option>
                                          <option value="Hyundai">Hyundai</option>
                                          <option value="Kia">Kia</option>
                                          <option value="Lexus">Lexus</option>
                                          <option value="Mazda">Mazda</option>
                                          <option value="Mitshubishi">Mitsubishi</option>
                                          <option value="Nissan">Nissan</option>
                                          <option value="Subaru">Subaru</option>
                                          <option value="Suzuki">Suzuki</option>
                                          <option value="Toyota">Toyota</option>
                                        </select>
                                    </div>
                                </div>

                                 <div class="control-group col-xs-6">
                                    
                                    <div class="controls" >
                                       
                                         <select required aria-required="true"  class="form-control" id="model" name="model" >
                                            <option selected value="">Modelis:</option>
                     
                                         </select>
                                    </div>
                                </div>
                              
                              <div class="control-group col-xs-6" >
                                
                                    <div class="controls"  >
                                         <select required aria-required="true"   class="form-control " id="year" name="year" >
                                          <option selected value="">Metai nuo:</option>
                                          <option>2018</option>
                                          <option>2017</option>
                                          <option>2016</option>
                                          <option>2015</option>
                                          <option>2014</option>
                                          <option>2013</option>
                                          <option>2012</option>
                                          <option>2011</option>
                                          <option>2010</option>
                                          <option>2009</option>
                                          <option>2008</option>
                                          <option>2007</option>
                                          <option>2006</option>
                                          <option>2005</option>
                                          <option>2004</option>
                                          <option>2003</option>
                                          <option>2002</option>
                                          <option>2001</option>
                                          <option>2000</option>
                                          <option>1999</option>
                                          <option>1998</option>
                                          <option>1997</option>
                                          <option>1996</option>
                                          <option>1995</option>
                                          <option>1994</option>
                                        </select>
                                    </div>
                                </div>
                              
                              
                                <div class="control-group col-xs-6" >
                                  
                                    <div class="controls"  >
                                         <select required aria-required="true"   class="form-control " id="year1" name="year1" >
                                          <option selected value="">Metai iki:</option>
                                          <option>2018</option>
                                          <option>2017</option>
                                          <option>2016</option>
                                          <option>2015</option>
                                          <option>2014</option>
                                          <option>2013</option>
                                          <option>2012</option>
                                          <option>2011</option>
                                          <option>2010</option>
                                          <option>2009</option>
                                          <option>2008</option>
                                          <option>2007</option>
                                          <option>2006</option>
                                          <option>2005</option>
                                          <option>2004</option>
                                          <option>2003</option>
                                          <option>2002</option>
                                          <option>2001</option>
                                          <option>2000</option>
                                          <option>1999</option>
                                          <option>1998</option>
                                          <option>1997</option>
                                          <option>1996</option>
                                          <option>1995</option>
                                          <option>1994</option>
                                        </select>
                                    </div>
                                </div>
                                
            </div>
         
          <div class="form-actions col-lg-offset-11 ">
                <input type="submit" value="Filtruoti" class="btn btn-success">
              </div>
            </form>
          </div>
          </div>
        </div>

       <div class="col-lg-10 col-lg-offset-1">     
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Sukurti auto')): ?> <a class="btn btn-success " href="<?php echo e(url('/cars/add-cars')); ?>">Pridėti</a><?php endif; ?> &nbsp;
             <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Atspausdinti PDF')): ?><a class="btn btn-success " href="<?php echo e(url('/cars/print-cars')); ?>">Atspausdinti PDF</a><?php endif; ?>
            

                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>Automobilių duomenys</h5>
                        </div>
                        <div class="widget-content table-responsive ">
                            <table class="table table-bordered  data-table table-responsive" id="example">
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th >Nuotrauka</th>
                                    <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                  <th style="width: 15%">Veiksmas</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                   <th >Nuotrauka</th>
                                      <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                  <th style="width: 15%">Veiksmas</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="gradeX">
                                   <td><?php echo ++$i; ?></td>
                                <td>
                                    <?php if(!empty($car->image)): ?>
                                      <img src="<?php echo e(asset('/images/backend_images/cars/small/'.$car->image)); ?>" style="width:100px;">
                                         <?php else: ?>
                              <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:100px; ">
                                    <?php endif; ?>
                                  </td>
                                   <td><?php echo $car -> brand; ?></td>
                                   <td><?php echo $car -> model; ?></td>
                                   <td><?php echo $car -> year; ?></td>
                                   <td><?php echo $car -> fuel; ?></td>
                                   <td><?php echo $car -> gearbox; ?></td>
                                   <td><?php echo $car -> cubature; ?></td>
                                   <td><?php echo $car -> power; ?></td>
                                   <td><?php echo $car -> body_type; ?></td>
                                   <td><?php echo $car -> color; ?></td>
                                   <td><?php echo $car -> wheel; ?></td>
                                   <td><?php echo $car -> mileage; ?></td>
                                   <td>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Perziureti auto')): ?>   <a class="btn " href="#myModal<?php echo $car -> car_id; ?>" data-toggle="modal" style="color: #4169E1;"><i class="fa fa-eye"></i></a>| 
                                       <?php endif; ?>
                                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Redaguoti auto')): ?>  <a class="btn " href="<?php echo e(url('/cars/edit-cars/'. $car -> car_id )); ?>" style="color: green;"><i class="fa fa-edit"></i></a>|<?php endif; ?>
                                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Istrinti auto')): ?> <a id="delCar" class="btn " href="<?php echo e(url('/cars/delete-cars/'. $car -> car_id )); ?>" style="color: red;"> <i class="fa fa-trash" ></i></a><?php endif; ?>
                                   </td>
                               </tr>
                               <div id="myModal<?php echo $car -> car_id; ?>" class="modal hide">
                                          <div class="modal-header" style="height: auto;">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h2><?php echo $car -> brand; ?> <?php echo $car -> model; ?> - <?php echo $car -> year; ?> m.</h2>
                                          </div>

                                          <div class="modal-body">
                                            <div class="row">
                                            <div class="col-sm-6"><b>Kuro tipas</b>: <?php echo $car -> fuel; ?></div>
                                            <div class="col-sm-6"><b>Pavarų dėžės tipas</b>: <?php echo $car -> gearbox; ?></div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Kubatūra</b>: <?php echo $car -> cubature; ?> L</div>
                                            <div class="col-sm-6"><b>Galia</b>: <?php echo $car -> power; ?> kW</div>
                                          </div>
                                            <div class="row">  
                                            <div class="col-sm-6"><b>Kėbulo tipas</b>: <?php echo $car -> body_type; ?></div>
                                            <div class="col-sm-6"><b>Spalva</b>: <?php echo $car -> color; ?></div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Vairo padėtis</b>: <?php echo $car -> wheel; ?></div>
                                            <div class="col-sm-6"><b>Rida</b>: <?php echo $car -> mileage; ?> km</div>
                                            </div>
                                            <hr>
                                            <div>
                                              <?php if(!empty($car->image)): ?>
                                          <div >
                                     <img src="<?php echo e(asset('/images/backend_images/cars/small/'.$car->image)); ?>" style="width: 90%; " > </div>
                                      <?php else: ?>
                                      <div>
                              <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:90%; "></div>
                                    <?php endif; ?>
                                  </div>
                                      </div>
                                    </div>
                                
                                          
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  </div>
                                        </div>
                                       
                                </tbody>
                            </table>
                        </div>
                    </div>

                    
                                
                               
                </div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
  
  var model = []; 
 model["Honda"] = ["Accord", "Civic","Civic Type R","CR-V","CRX","Element", "FR-V","Insight","Odissey","Prelude","S2000"];
  model["Hyundai"] = ["Accent", "Coupe", "Getz", "i30"];
  model["Kia"] = ["Cee'd","Optima","Picanto", "Rio", "Sorento"];
  model["Lexus"] = ["ES 200","ES 240","ES 250","ES 300","IS 200","IS 250","IS 300","IS 350","GS 300","HS 250h"];
  model["Mazda"] = ["121", "2","3","323","323F","5","6","626","MX-5","RX-8","Premacy","Xedos 9"];
  model["Mitshubishi"] = ["Carisma","Colt","Eclipse","Galant","Lancer","Lancer Evolution","Pajero","SpaceStar"];
  model["Nissan"] = ["Almera","Altima","Juke","Leaf","Micra","Murano","Note","Tino","Xtrail"];
  model["Subaru"] = ["Forester","Impreza","Legacy","Outback","WRX"];
  model["Suzuki"] = ["Alto","Grand Vitara","Liana","Swift","SX 4"];
  model["Toyota"] = ["Aygo","Avensis","Auris","Camry","Corrola","Corrola Verso","Highlander","Yaris","Land Cruiser","Previa","Prius","RAV4","Verso"];
  
  function fillSelect(nValue,nList){

    nList.options.length = 1;
    var curr = model[nValue];
    for (each in curr)
      {
       var nOption = document.createElement('option'); 
       nOption.appendChild(document.createTextNode(curr[each])); 
       nOption.setAttribute("value",curr[each]);       
       nList.appendChild(nOption); 
      }
  }

</script>
    <?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>