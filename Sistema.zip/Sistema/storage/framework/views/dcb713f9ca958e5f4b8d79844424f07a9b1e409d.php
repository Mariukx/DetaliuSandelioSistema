<?php $__env->startSection('title', '| Car parts'); ?>

<?php $__env->startSection('content'); ?>


 
  

       <div class="col-lg-10 col-lg-offset-1">     
            <a class="btn btn-success btn-sm" href="<?php echo e(url('/admin/add-cars')); ?>">Pridėti</a>&nbsp;
            <a class="btn btn-success btn-sm" href="<?php echo e(url('/admin/print-cars')); ?>">Atspausdinti PDF</a>
            

                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>Automobilių duomenys</h5>
                        </div>
                        <div class="widget-content table-responsive ">
                            <table class="table table-bordered  data-table table-responsive" id="example">
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th>Brand</th>
                                    <th style="width: 5%" >ID</th>
                                    <th style="width: 10%" >Model</th>
                                    <th style="width: 5%" >Year</th>
                                    <th>Fuel</th>
                                    <th>Gearbox</th>
                                    <th>Cubature</th>
                                    <th>Power</th>
                                    <th style="width: 5%" >Quantity</th>
                                  <th style="width: 15%">Action</th>
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th>Brand</th>
                                    <th style="width: 5%" >ID</th>
                                    <th style="width: 10%" >Model</th>
                                    <th style="width: 5%" >Year</th>
                                    <th>Fuel</th>
                                    <th>Gearbox</th>
                                    <th>Cubature</th>
                                    <th>Power</th>
                                    <th style="width: 5%" >Quantity</th>
                                  <th style="width: 17%">Action</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="gradeX">
                                   <td><?php echo ++$i; ?></td>
                                   <td><?php echo $car -> brand; ?></td>
                                   <td> <?php echo $car -> id; ?></td>
                                   <td><?php echo $car -> model; ?></td>
                                   <td><?php echo $car -> year; ?></td>
                                   <td><?php echo $car -> fuel; ?></td>
                                   <td><?php echo $car -> gearbox; ?></td>
                                   <td><?php echo $car -> cubature; ?></td>
                                   <td><?php echo $car -> power; ?></td>
                                   <td><?php echo $car -> quantity; ?></td>
                                   <td>
                                       <a class="btn btn-info btn-sm" href="<?php echo e(url('/admin/edit-cars/'. $car -> id )); ?>"> Redaguoti</a>
                                       <a id="delCar" class="btn btn-danger btn-sm" href="<?php echo e(url('/admin/delete-cars/'. $car -> id )); ?>">Ištrinti</a>
                                   </td>
                               </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
     
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>