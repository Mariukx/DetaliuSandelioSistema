<!Doctype html>
  <html lang="en">
   <head>
    <meta charset="UTF-8">
      <title>Cars</title>
                <style type="text/css">

                          #cars {
                          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                          }

                          #cars td, #cars th {
                              border: 1px solid #ddd;
                              padding: 8px;
                          }

                          #cars tr:nth-child(even){
                            background-color: #f2f2f2;
                          }

                          #cars tr:hover {
                            background-color: #ddd;
                          }

                          #cars th {
                              padding-top: 12px;
                              padding-bottom: 12px;
                              text-align: left;
                              background-color: #4CAF50;
                              color: white;
                          }
              </style>
   </head>

          <body>

            <h1>Automobiliai</h1>
                            <table id="cars">
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    
                                    <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                 
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                   
                                      <th style="width: 8%">Markė</th>
                                    <th style="width: 8%" >Modelis</th>
                                    <th style="width: 5%" >Metai</th>
                                    <th style="width: 5%">Kuras</th>
                                    <th style="width: 5%">Pavaros</th>
                                    <th style="width: 5%">Kubatūra</th>
                                    <th style="width: 5%">Galia</th>
                                    <th style="width: 5%" >Kėbulas</th>
                                    <th style="width: 5%" >Spalva</th>
                                    <th style="width: 5%" >Vairas</th>
                                    <th style="width: 5%" >Rida</th>
                                  
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                <?php $__currentLoopData = $cars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr>
                                   <td><?php echo ++$i; ?></td>
                                 
                                   <td><?php echo $car -> brand; ?></td>
                                   <td><?php echo $car -> model; ?></td>
                                   <td><?php echo $car -> year; ?></td>
                                   <td><?php echo $car -> fuel; ?></td>
                                   <td><?php echo $car -> gearbox; ?></td>
                                   <td><?php echo $car -> cubature; ?></td>
                                   <td><?php echo $car -> power; ?></td>
                                   <td><?php echo $car -> body_type; ?></td>
                                   <td><?php echo $car -> color; ?></td>
                                   <td><?php echo $car -> wheel; ?></td>
                                   <td><?php echo $car -> mileage; ?></td>
                                  
                               </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
       
       
          
          
          </body>
        </html>