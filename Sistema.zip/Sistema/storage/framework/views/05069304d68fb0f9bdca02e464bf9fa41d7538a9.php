<!Doctype html>
  <html lang="en">
   <head>
    <meta charset="UTF-8">
      <title>carparts</title>
                <style type="text/css">

                          #carparts {
                          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                          }

                          #carparts td, #carparts th {
                              border: 1px solid #ddd;
                              padding: 8px;
                          }

                          #carparts tr:nth-child(even){
                            background-color: #f2f2f2;
                          }

                          #carparts tr:hover {
                            background-color: #ddd;
                          }

                          #carparts th {
                              padding-top: 12px;
                              padding-bottom: 12px;
                              text-align: left;
                              background-color: #4CAF50;
                              color: white;
                          }
              </style>
   </head>

          <body>

            <h1>Automobilių dalys</h1>
                            <table id="carparts">
                                <thead>
                                <tr>
                                      <th style="width: 5%" >Nr.</th>
                                    <th style="width: 8%">Detalės pavadinimas</th>
                                    <th style="width: 18%">Automobilis</th>
                                    <th style="width: 5%">Kaina</th>
                                    <th style="width: 3%">Kiekis</th>
                                    <th style="width: 5%">Spalva</th>
                                    <th style="width: 5%">Gamintojas</th>
                                    <th style="width: 5%">Detalės pusė</th>
                                    <th style="width: 7%">Aprašymas</th>
                                    <th style="width: 6%">Adresas</th>
                                    <th style="width: 3%">Vietos kodas</th>
                                    
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th style="width: 8%">Detalės pavadinimas</th>
                                    <th style="width: 18%">Automobilis</th>
                                    <th style="width: 5%">Kaina</th>
                                    <th style="width: 3%">Kiekis</th>
                                    <th style="width: 5%">Spalva</th>
                                    <th style="width: 5%">Gamintojas</th>
                                    <th style="width: 5%">Detalės pusė</th>
                                    <th style="width: 7%">Aprašymas</th>
                                    <th style="width: 6%">Adresas</th>
                                    <th style="width: 3%">Vietos kodas</th>
                                   
                                    
                                </tr>
                                </tfoot>
                                <tbody>
                                  <?php
                                  $i = 0;
                                  ?>
                               <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="gradeX">
                                   <td><?php echo ++$i; ?></td>
                                   <td><?php echo $part -> p_name; ?></td>
                                   <td><?php echo $part -> brand; ?>  <?php echo $part -> model; ?> - <?php echo $part -> year; ?> m.,  <?php echo $part -> power; ?> kW,  <?php echo $part -> cubature; ?> L</td>
                                  
                                   <td><?php echo $part -> p_price; ?></td>
                                   <td><?php echo $part -> p_quantity; ?></td>
                                   <td><?php echo $part -> p_color; ?></td>
                                   <td><?php echo $part -> p_vendor; ?></td>
                                   <td><?php echo $part -> p_side; ?></td>
                                   <td><?php echo $part -> p_description; ?></td>
                                   <td><?php echo $part -> w_address; ?></td> 
                                   <td><?php echo $part -> section; ?><?php echo $part -> stack; ?><?php echo $part -> shelve; ?><?php echo $part -> slot; ?></td>
                               </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
       
       
          
          
          </body>
        </html>