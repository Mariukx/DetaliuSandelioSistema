<?php $__env->startSection('title', '| Parts'); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
@media  screen and (max-width: 500px){
    .widget-content {
       
        top: 50%;
    left: 50%;
    margin-right: -50%;
    }
}
@media  screen and (max-width: 400px){
    img {
       
        top: 50%;
    left: 50%;
    margin-right: -50%;
    }
}

    </style>

<h2 style="text-align: center;">Detalių sąrašas</h2>
 <a class="btn btn-primary btn-sm" href="<?php echo e(url('/index')); ?>" style=" margin-left: 35px"> <h4 style="text-align: left; margin-top: 10px; " >Grįžti atgal į galeriją</h4></a> 
  <div class="container-fluid">
  	<div class="row">
  		<div class="col-lg-3">
  			<div class="widget-box" style="height: auto; margin-left: 20px;">
  		 <div class="widget-content" style="height: auto;  box-shadow: 1px 2px 3px #888888; padding: 10px; width: 100%; background-color: #F0F8FF;">
  		 <h4 style="text-align: center;"><strong>Turite klausimų? </strong></h4>
        <form>
          <div class="form-group">
            <input type="text" class="form-control" name="" value="" placeholder="Vardas">
          </div>
          <div class="form-group">
            <input type="email" class="form-control" name="" value="" placeholder="El. paštas">
          </div>
          <div class="form-group">
            <input type="tel" class="form-control" name="" value="" placeholder="Tel. numeris">
          </div>
          <div class="form-group">
            <textarea class="form-control" name="" rows="3" placeholder="Žinutė"></textarea>
          </div>
          <button class="btn btn-primary" type="submit" name="button">
              <i class="fa fa-paper-plane-o" aria-hidden="true"></i> Išsiųsti
          </button>
        </form>
    </div>
  			</div>
  		</div>
  	
  

   <div class='col-lg-8 col-lg-offset-0' >
    <div class="widget-box" style="height: auto; background-color: #F0F8FF; ">
    	 <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
    	<div class="widget-content" style="height: auto;   box-shadow: 0px 0.5px 0px 0px #4169E1; padding: 10px; font-size: 18px; ">
                             
                                   			<div class="row">
                                   				<div class="col-sm-3">
                                   				<?php if(!empty($part->p_image)): ?>
					                                      <img src="<?php echo e(asset('/images/backend_images/parts/small/'.$part->p_image)); ?>" style="width:140px; height: 120px; ">
					                                       <?php else: ?>
					                              <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:140px; height: 120px; ">
					                                <?php endif; ?>
					                            </div>
                                            <div class="col-sm-3"><b>Pavadinimas</b>: <?php echo $part -> p_name; ?></div>
                                            <div class="col-sm-3"><b>Kaina</b>: <?php echo $part -> p_price; ?> €</div>
                                            <div class="col-sm-3"><b>Kiekis</b>: <?php echo $part -> p_quantity; ?></div>
                                            <div class="col-sm-3"><b>Spalva</b>: <?php echo $part -> p_color; ?> </div>
                                            <div class="col-sm-3"><b>Detalės pusė</b>: <?php echo $part -> p_side; ?></div>
                                            <div class="col-sm-3"><b>Gamintojas</b>: <?php echo $part -> p_vendor; ?></div>
                                            <div class="col-sm-3"><b>Aprašymas</b>: <?php echo $part -> p_description; ?> </div>
                                             <div class="col-sm-3">  </div>

                                         	 <div class="col-sm-3">          
            								 	<a class="btn btn-primary  " href="#myModal<?php echo $part -> part_id; ?>" data-toggle="modal" >Peržiūrėti</a>
                                             </div>
                                             <div class="row">

                                             </div>
                                             <div class="row">

                                            </div>
                                            <div class="row">
												
            								 </div>
                                            </div>                  
                                           
            							<div id="myModal<?php echo $part -> part_id; ?>" class="modal hide">
                                          <div class="modal-header">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h2><?php echo $part -> brand; ?> <?php echo $part -> model; ?> - <?php echo $part -> year; ?> m. </h2>
                                          </div>

                                          <div class="modal-body">

                                          <h4>  <?php echo $part -> power; ?> kW, <?php echo $part -> cubature; ?> L, <?php echo $part -> fuel; ?> <a href="<?php echo e(url('/inventory/send-order/'.$part -> part_id)); ?>" class="btn btn-default pull-right">Užsakyti</a></h4>

                                            <hr>
                                           <div class="row"> 
	                                           	<div class="col-sm-6"><b>Vairas pusė</b>: <?php echo $part -> wheel; ?></div>
	                                           	<div class="col-sm-6"><b>Pavarų dėžė</b>: <?php echo $part -> gearbox; ?></div>
                                           	</div> 
                                           	<div class="row">
                                           			<div class="col-sm-6"><b>Automobilio spalva</b>: <?php echo $part -> color; ?> </div>
                                           			<div class="col-sm-6"><b>Kėbulo tipas</b>: <?php echo $part -> body_type; ?></div>
                                           	</div> 
                                           	<div class="row">
                                           		<div class="col-sm-6"><b>Rida</b>: <?php echo $part -> mileage; ?> km.</div>
                                           		</div> 
                                            <b>Adresas</b>: <?php echo $part -> w_address; ?>.
                                            <hr>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Pavadinimas</b>: <?php echo $part -> p_name; ?></div>
                                            <div class="col-sm-6" style="background-color: green; color:  white; font-size: 15px;"><b>Kaina: <?php echo $part -> p_price; ?> € </b></div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Kiekis</b>: <?php echo $part -> p_quantity; ?></div> 
                                             <div class="col-sm-6"><b>Spalva</b>: <?php echo $part -> p_color; ?> </div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Detalės pusė</b>: <?php echo $part -> p_side; ?></div>
                                            
                                             <div class="col-sm-6"><b>Gamintojas</b>: <?php echo $part -> p_vendor; ?></div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Aprašymas</b>: <?php echo $part -> p_description; ?> </div>
                                            </div>
                                            <hr>
                                            <div >
                                              <?php if(!empty($part->p_image)): ?>

                                      <img src="<?php echo e(asset('/images/backend_images/parts/small/'.$part->p_image)); ?>" style="width:90%;" >
                                      <?php else: ?>
                                      <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:90%; ">
                                    <?php endif; ?>
                                  </div>
                                      </div>
                                    </div>
		               </div>
		                 	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		        </div>                          
        </div>
                             
            </div>   

      </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>