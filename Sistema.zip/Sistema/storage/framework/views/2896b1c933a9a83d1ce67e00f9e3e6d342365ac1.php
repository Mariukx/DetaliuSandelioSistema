<?php $__env->startSection('title', '| Roles'); ?>

<?php $__env->startSection('content'); ?>

<div class="col-lg-10 col-lg-offset-1">
    <h1><i class="fa fa-key"></i> Rolės

    <div><a href="<?php echo e(route('users.index')); ?>" class="btn btn-info pull-right">Naudotojai</a>
    <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-info pull-right">Leidimai</a></div></h1>
    <hr>
     <div class="widget-box">
             <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                  <h5>Rolės</h5>          
            </div>           
    <div class="widget-content table-responsive">
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Rolė</th>
                    <th>Leidimas</th>
                    <th style="width: 17%;">Veiksmas</th>
                </tr>
            </thead>

            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><?php echo e($role->name); ?></td>

                    <td><?php echo e(str_replace(array('[',']' , '"'),'', $role->permissions()->pluck('name'))); ?></td>
                    <td>
                    <a href="<?php echo e(URL::to('roles/'.$role->id.'/edit')); ?>" class="btn btn-info pull-left">Redaguoti</a>

                    <?php echo Form::open(['method' => 'DELETE', 'route' => ['roles.destroy', $role->id] ]); ?>

                    <?php echo Form::submit('Ištrinti', ['class' => 'btn btn-danger']); ?>

                    <?php echo Form::close(); ?>


                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>

        </table>
    </div>
</div>
    <a href="<?php echo e(URL::to('roles/create')); ?>" class="btn btn-success">Pridėti rolę</a>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>