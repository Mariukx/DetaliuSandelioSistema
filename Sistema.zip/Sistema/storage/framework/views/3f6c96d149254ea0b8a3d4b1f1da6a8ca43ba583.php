<?php $__env->startSection('content'); ?>
 
        <?php if(Session:: has('flash_message_error')): ?>

            <div class="alert alert-danger alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  <?php echo session('flash_message_error'); ?></strong>
            </div>
             &nbsp;
        <?php endif; ?>

        <?php if(Session:: has('flash_message_success')): ?>

            <div class="alert alert-success alert-block">
                <button type="button" class="close" data-dismiss="alert">×</button>
                <strong>  <?php echo session('flash_message_success'); ?></strong>
            </div>
             &nbsp;
        <?php endif; ?>
       
      <div class="col-lg-10 col-lg-offset-1">     
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Sukurti detale')): ?> <a class="btn btn-success " href="<?php echo e(url('/parts/add-parts')); ?>">Pridėti</a><?php endif; ?> &nbsp;
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Atspausdinti PDF')): ?><a class="btn btn-success " href="<?php echo e(url('/parts/print-parts')); ?>">Atspausdinti PDF</a><?php endif; ?>
            


                    <div class="widget-box">
                        <div class="widget-title"> <span class="icon"><i class="icon-th"></i></span>
                            <h5>Detalių duomenys</h5>
                        </div>
                        <div class="widget-content table-responsive">
                            <table class="table table-bordered  data-table table-responsive" id="example">
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th >Nuotrauka</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                    <th style="width: 15%">Veiksmas</th>
                                   
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                   <th style="width: 5%" >Nr.</th>
                                   <th >Nuotrauka</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 5%">Spalvos kodas</th>
                                    <th style="width: 5%">Detalės kodas</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                    <th style="width: 15%">Veiksmas</th>
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="gradeX">
                                   <td><?php echo ++$i; ?></td>
                                   <td>
                                    <?php if(!empty($part->p_image)): ?>
                                      <img src="<?php echo e(asset('/images/backend_images/parts/small/'.$part->p_image)); ?>" style="width:100px;">
                                       <?php else: ?>
                              <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:100px; ">
                                    <?php endif; ?>
                                  </td>
                                   <td><?php echo $part -> car_id; ?></td>
                                   <td><?php echo $part -> wh_id; ?></td>
                                   <td><?php echo $part -> location_id; ?></td>
                                   <td><?php echo $part -> p_name; ?></td>
                                   <td><?php echo $part -> p_price; ?></td>
                                   <td><?php echo $part -> p_quantity; ?></td>
                                   <td><?php echo $part -> p_color; ?></td>
                                   <td><?php echo $part -> p_color_code; ?></td>
                                   <td><?php echo $part -> p_code; ?></td>
                                   <td><?php echo $part -> p_side; ?></td>
                                   <td><?php echo $part -> p_vendor; ?></td>
                                   <td><?php echo $part -> p_description; ?></td>                                
                                   <td>
                                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Perziureti detale')): ?>   <a class="btn  " href="#myModal<?php echo $part -> part_id; ?>" data-toggle="modal" style="color: #4169E1;"><i class="fa fa-eye"></i></a>|
                                       <?php endif; ?>
                                     <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Redaguoti detale')): ?>  <a class="btn " href="<?php echo e(url('/parts/edit-parts/'. $part -> part_id )); ?>" style="color: green;"><i class="fa fa-edit"></i></a>|<?php endif; ?>
                                      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Istrinti detale')): ?><a id="delPart"  class="btn " href="<?php echo e(url('/parts/delete-parts/'. $part -> part_id )); ?>" style="color: red;"> <i class="fa fa-trash" ></i></a> <?php endif; ?>
                                   </td>
                               </tr>
                                     <div id="myModal<?php echo $part -> part_id; ?>" class="modal hide">
                                          <div class="modal-header" style="height: auto;">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h2><?php echo $part -> brand; ?> <?php echo $part -> model; ?> - <?php echo $part -> year; ?> m. </h2>
                                          </div>

                                          <div class="modal-body">
                                            <?php echo $part -> power; ?> kW, <?php echo $part -> cubature; ?> L, <?php echo $part -> fuel; ?>  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;      |  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;
                                            <?php echo $part -> w_address; ?> - <?php echo $part -> section; ?><?php echo $part -> stack; ?><?php echo $part -> shelve; ?><?php echo $part -> slot; ?>

                                            <hr>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Pavadinimas</b>: <?php echo $part -> p_name; ?></div>
                                            <div class="col-sm-6"><b>Kaina</b>: <?php echo $part -> p_price; ?> €</div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Kiekis</b>: <?php echo $part -> p_quantity; ?></div> 
                                             <div class="col-sm-6"><b>Spalva</b>: <?php echo $part -> p_color; ?> </div>
                                             </div>
                                             <div class="row">
                                             <div class="col-sm-6"><b>Detalės pusė</b>: <?php echo $part -> p_side; ?></div>
                                            
                                             <div class="col-sm-6"><b>Gamintojas</b>: <?php echo $part -> p_vendor; ?></div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Aprašymas</b>: <?php echo $part -> p_description; ?> </div>
                                            <div class="col-sm-6"><b>Detalės kodas</b>: <?php echo $part -> p_code; ?> </div>
                                            </div>
                                            <div class="row">
                                            
                                            <div class="col-sm-6"><b>Detalės kodas</b>: <?php echo $part -> p_color_code; ?> </div>
                                            </div>
                                            <hr>
                                            <div >
                                              <?php if(!empty($part->p_image)): ?>

                                      <img src="<?php echo e(asset('/images/backend_images/parts/small/'.$part->p_image)); ?>" style="width: 90%;" >
                                      <?php else: ?>
                                      <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:90%; ">
                                    <?php endif; ?>
                                  </div>
                                      </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                              </div>
                            </div>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

  
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>