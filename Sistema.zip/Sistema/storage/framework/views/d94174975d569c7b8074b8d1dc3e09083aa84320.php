<?php $__env->startSection('title', '| Create New Post'); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-10 col-lg-offset-1">
     <div class="widget-box">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">

        <h1>Sukurti naują straipsnį</h1>
        <hr>

    
        <?php echo e(Form::open(array('route' => 'posts.store'))); ?>


        <div class="form-group">
            <?php echo e(Form::label('title', 'Pavadinimas')); ?>

            <?php echo e(Form::text('title', null, array('class' => 'form-control'))); ?>

            <br>

            <?php echo e(Form::label('body', 'Turinys')); ?>

            <?php echo e(Form::textarea('body', null, array('class' => 'form-control'))); ?>

            <br>

            <?php echo e(Form::submit('Sukurti', array('class' => 'btn btn-success btn-lg btn-block'))); ?>

            <?php echo e(Form::close()); ?>

        </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>