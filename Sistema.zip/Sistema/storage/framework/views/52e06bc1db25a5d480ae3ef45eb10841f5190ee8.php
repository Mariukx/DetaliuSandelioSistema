
<!DOCTYPE html>
<html lang="<?php echo e(config('app.locale')); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Carparts')); ?></title>
   
    <!-- Styles -->
   <!-- <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">-->
    <link href="https://fonts.googleapis.com/css?family=Montserrat" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Lato" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
 
   <!-- <link rel="stylesheet" href="<?php echo e(asset('css/backend_css/bootstrap.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/backend_css/bootstrap-responsive.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/backend_css/fullcalendar.css')); ?>" />-->
   <link rel="stylesheet" href="<?php echo e(asset('css/backend_css/matrix-style.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('css/backend_css/matrix-media.css')); ?>" />
    <link href="<?php echo e(asset('css/styles.css')); ?>" rel="stylesheet">

   <!-- <link rel="stylesheet" href="<?php echo e(asset('css/backend_css/select2.css')); ?>" />
    <link href="<?php echo e(asset('fonts/backend_fonts/css/font-awesome.css')); ?>" rel="stylesheet" />
    <link rel="stylesheet" href="<?php echo e(asset('css/backend_css/jquery.gritter.css')); ?>" />-->
    <!-- Scripts -->
    <script>
        window.Laravel = <?php echo json_encode([
            'csrfToken' => csrf_token(),
        ]); ?>;
    </script>
    <script src="https://use.fontawesome.com/9712be8772.js"></script>
</head>
<body >
    <div id="app" style="margin-top:50px">
        <nav class="navbar navbar-inverse navbar-fixed-top"  >
            <div class="container">
                <div class="navbar-header">

                    <!-- Collapsed Hamburger -->
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#app-navbar-collapse">
                        <span class="sr-only">Toggle Navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    &nbsp;
                    <!-- Branding Image -->
                   <a href="<?php echo e(url('/')); ?>"><img src="<?php echo e(asset('images/backend_images/logo.png')); ?>"></a>

                </div>

                <div class="collapse navbar-collapse" id="app-navbar-collapse">
                    <!-- Left Side Of Navbar -->
                    <ul class="nav navbar-nav">
                        <li><a href="<?php echo e(url('/index')); ?>">PAGRINDINIS</a></li>
                        <?php if(!Auth::guest()): ?>
                          <!--   <li><a href="<?php echo e(route('posts.create')); ?>">NAUJAS STRAIPSNIS</a></li>
                            <li><a href="<?php echo e(url('/cars/view-cars')); ?>">AUTOMOBILIAI</a></li>
                            <li><a href="<?php echo e(url('/parts/view-parts')); ?>">DALYS</a></li>-->
                         <?php endif; ?>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="nav navbar-nav navbar-right">
                        <!-- Authentication Links -->
                        <?php if(Auth::guest()): ?>
                            <li><a href="<?php echo e(route('login')); ?>">PRISIJUNGTI</a></li>
                            <li><a href="<?php echo e(route('register')); ?>">REGISTRUOTIS</a></li>
                        <?php else: ?>
                            <li class="dropdown">
                                <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded="false">
                                    <?php echo e(Auth::user()->name); ?> <span class="caret"></span>
                                </a>

                                <ul class="dropdown-menu" role="menu">
                                    <li>
                                        <?php if(auth()->check() && auth()->user()->hasRole('Administratorius')): ?> 
                                        <a href="<?php echo e(url('users')); ?>"><i class="fa fa-btn fa-unlock"></i> DARBUOTOJAI</a>
                                        <a href="<?php echo e(url('/inventory/carparts')); ?>"><i class="fa fa-archive"></i> 
                                        INVENTORIUS</a>
                                        <a href="<?php echo e(url('/cars/view-cars')); ?>"><i class="fa fa-btn fa-car"></i> AUTOMOBILIAI</a>
                                        <a href="<?php echo e(url('/parts/view-parts')); ?>"><i class="fa fa-cogs"></i></i> DALYS</a>
                                        <?php endif; ?>
                                         <?php if(auth()->check() && auth()->user()->hasRole('Vadybininkas')): ?> 
                                       
                                        <a href="<?php echo e(url('/inventory/carparts')); ?>"><i class="fa fa-archive"></i> INVENTORIUS</a>

                                        <?php endif; ?>
                                        <?php if(auth()->check() && auth()->user()->hasRole('Sandėlininkas')): ?> 
                                        <a href="<?php echo e(url('/cars/view-cars')); ?>"><i class="fa fa-btn fa-car"></i> AUTOMOBILIAI</a>
                                        <a href="<?php echo e(url('/parts/view-parts')); ?>"><i class="fa fa-cogs"></i> DALYS</a>
                                        <a href="<?php echo e(url('/inventory/carparts')); ?>"><i class="fa fa-archive"></i> INVENTORIUS</a>

                                        <?php endif; ?>
                                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault(); document.getElementById('logout-form').submit();"><i class="fa fa-arrow-right"></i>
                                       Atsijungti
                                               </a>

                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                            <?php echo e(csrf_field()); ?>

                                        </form>
                                    </li>
                                </ul>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </div>
        </nav>

        <?php if(Session::has('flash_message')): ?>
            <div class="container">      
                <div class="alert alert-success"><em> <?php echo session('flash_message'); ?></em>
                </div>
            </div>
        <?php endif; ?> 

        <div class="row">
            <div class="col-md-8 col-md-offset-2">              
                <?php echo $__env->make('errors.list', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?> 
            </div>
        </div>

        <?php echo $__env->yieldContent('content'); ?>

    </div>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>"></script>
  
   

   <!--  <script src="<?php echo e(asset('js/backend_js/jquery.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('js/backend_js/jquery.ui.custom.js')); ?>"></script> 
    <script src="<?php echo e(asset('js/backend_js/bootstrap.min.js')); ?>"></script> 
    <script src="<?php echo e(asset('js/backend_js/jquery.uniform.js')); ?>"></script> 
    <script src="<?php echo e(asset('js/backend_js/select2.min.js')); ?>"></script> -->
    <script src="<?php echo e(asset('js/backend_js/jquery.validate.js')); ?>"></script>
    <script src="<?php echo e(asset('js/backend_js/matrix.js')); ?>"></script> 
    <script src="<?php echo e(asset('js/backend_js/matrix.form_validation.js')); ?>"></script>
    <script src="<?php echo e(asset('js/backend_js/jquery.dataTables.min.js')); ?>"></script>
   
    <script src="<?php echo e(asset('js/backend_js/matrix.tables.js')); ?>"></script>
    <script src="<?php echo e(asset('js/backend_js/jquery.printPage.js')); ?>"></script> 
     <script src="<?php echo e(asset('js/backend_js/matrix.popover.js')); ?>"></script>
</body>
</html>