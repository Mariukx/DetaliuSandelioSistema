<?php $__env->startSection('title', '| Parts'); ?>

<?php $__env->startSection('content'); ?>
<div class='col-lg-4 col-lg-offset-4'>
    <div class="widget-box">
        <div class="widget-content">
           <h1><i class='fa fa-key'></i> Redaguoti detalę</h1>
    <hr>

    <?php echo e(Form::open(array('url' => '/parts/edit-parts/'.$partDetails->part_id,'enctype'=>'multipart/form-data'))); ?>

                
                                  <!--     <div class="widget-box">
                        <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
                            <h5>Add Cars</h5>
                        </div>

                        <div class="widget-content nopadding">
                            <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/add-parts')); ?>" name="add_cars" id="add_cars" novalidate="novalidate">-->

                        
                                   <?php echo e(csrf_field()); ?>

                            <div class="control-group">
                                  <div class="controls">
                                    <?php echo e(Form::label('brand', 'Markė:')); ?>

                                    <?php echo Form::select('car_id', $cars,$partDetails->car_id ?: old('car_id'), array('class' => 'form-control') ); ?>

                                </div>
                                </div>

                                  <div class="control-group">
                                 <div class="controls">
                                    <?php echo e(Form::label('warehouse', 'Sandėlio adresas:')); ?>

                                    <?php echo Form::select('wh_id', $warehouse,$partDetails->wh_id ?: old('wh_id'), array('class' => 'form-control') ); ?>

                                </div>
                                  </div>
                                  <div class="control-group">
                                   
                                    <div class="controls">
                                    <?php echo e(Form::label('location', 'Vietos kodas:')); ?>

                                    <?php echo Form::select('location_id', $location,$partDetails->location_id ?: old('location_id'), array('class' => 'form-control') ); ?>

                                    </div>
                                  </div>
                                <div class="control-group">
                                    <label class="control-label">Detalės pavadinimas:</label>   
                                    <div class="controls">
                                        <input type="text" class="form-control"  name="p_name" id="p_name" value="<?php echo e($partDetails->p_name); ?>" required/>
                                    </div>
                                  </div>
                                   <div class="control-group">
                                    <label class="control-label">Kaina:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="10000" step="0.01" name="p_price" id="p_price" value="<?php echo e($partDetails->p_price); ?>" required/>
                                    </div>
                                  </div>
                                   <div class="control-group">
                                    <label class="control-label">Kiekis:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="200" name="p_quantity" id="p_quantity"  value="<?php echo e($partDetails->p_quantity); ?>" required/>
                                    </div>
                                  </div>
                                   <div class="control-group">
                                    <?php echo e(Form::label('p_color', 'Spalva')); ?>

                                   <?php echo e(Form::select('p_color',['Nėra'=>'Nėra','Balta'=>'Balta','Geltona/aukso'=>'Geltona/aukso','Juoda'=>'Juoda','Mėlyna'=>'Mėlyna','Oranžinė'=>'Oranžinė','Pilka/sidabrinė'=>'Pilka/sidabrinė','Raudona/vyšninė'=>'Raudona/vyšninė','Ruda/smėlio'=>'Ruda/smėlio','Violetinė'=>'Violetinė','Žalia/chaki'=>'Žalia/chaki','Kita'=>'Kita'], $partDetails->p_color ?: old('p_color'), ['class' => 'form-control'])); ?>

                                  </div>
                                  <div class="control-group">
                                    <label class="control-label">Detalės kodas:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="9999999" name="p_code" id="p_code"  value="<?php echo e($partDetails->p_code); ?>" required/>
                                    </div>
                                  </div>
                                  <div class="control-group">
                                    <label class="control-label">Spalvos kodas:</label>   
                                    <div class="controls">
                                        <input type="number" class="form-control"  min="0" max="9999999" name="p_color_code" id="p_color_code"  value="<?php echo e($partDetails->p_color_code); ?>" >
                                    </div>
                                  </div>
                                  <div class="control-group">
                                    <div class="controls">
                                       
                                   <?php echo e(Form::label('p_side', 'Detalės pusė')); ?>

                                   <?php echo e(Form::select('p_side',['Nėra'=>'Nėra','Dešinė/Priekis'=>'Dešinė/Priekis', 'Dešinė/Galas'=>'Dešinė/Galas', 'Kairė/Galas'=> 'Kairė/Galas', 'Kairė/Priekis'=>'Kairė/Priekis','Priekis'=> 'Priekis','Galas'=> 'Galas' ], $partDetails->p_side ?: old('p_side'), ['class' => 'form-control'])); ?>

                                  </div>
                                    </div>
                                 
                                   <div class="control-group">
                                    <div class="controls">
                                     <?php echo e(Form::label('p_vendor', 'Gamintojas')); ?>

                                   <?php echo e(Form::select('p_vendor',['Nėra'=>'Nėra','Bosh'=>'Bosh','Dunlop'=>'Dunlop','GoodYear'=> 'GoodYear',  'Kita'=> 'Kita'], $partDetails->p_vendor ?: old('p_vendor'), ['class' => 'form-control'])); ?>

                                  </div>
                                  </div>
                                  
                                  <div class="control-group">
                                    <label class="control-label">Aprašymas:</label>   
                                    <div class="controls">
                                        <input  type="text" class="form-control" max="255" name="p_description" id="p_description"  value="<?php echo e($partDetails->p_description); ?>" required/>
                                    </div>
                                  </div>
                                    
                                <div class="control-group">
                                  <label class="control-label">Nuotrauka:</label>
                                  <div class="controls">
                                    <input type="file" class="form-control" name="p_image" id="p_image">
                                    <input type="hidden" name="current_image"  id="current_image" value="<?php echo e($partDetails->p_image); ?>" accept="image/x-png,image/gif,image/jpeg">
                                    <?php if(!empty($partDetails->p_image)): ?>
                                    <img style="width: 100px;" src="<?php echo e(asset('/images/backend_images/parts/small/'.$partDetails->p_image)); ?>" > <a href="<?php echo e(url('/parts/delete-parts-image/'.$partDetails->part_id)); ?>">Panaikinti</a>
                                    <?php endif; ?>
                                  </div>
                                </div>
                                  &nbsp;
                                   <div class='form-group'>
                              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Redaguoti detale')): ?>  <?php echo e(Form::submit('Išsaugoti', array('class' => 'btn btn-primary'))); ?><?php endif; ?>
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Grįžti atgal</a>

                    <?php echo e(Form::close()); ?>

                           
                        </div>
                    </div>
                </div>
        </div>
    </div>

    
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>