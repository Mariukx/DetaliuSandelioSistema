<?php $__env->startSection('title', '| Parts'); ?>

<?php $__env->startSection('content'); ?>
<style type="text/css">
  @media  screen and (max-width: 400px){
    .control-group{
        width: 90%;
        height: auto;
        margin: auto;
        
    }
}
</style>
<div class='col-lg-4 col-lg-offset-4'>
    <div class="widget-box">
        <div class="widget-content">
           <h1><i class='fa fa-key'></i> Pridėti detalę</h1>
    <hr>

    <?php echo e(Form::open(array('url' => 'parts/add-parts', 'enctype'=>'multipart/form-data'))); ?>

                
                                  <!--     <div class="widget-box">
                        <div class="widget-title"> <span class="icon"> <i class="icon-info-sign"></i> </span>
                            <h5>Add Cars</h5>
                        </div>

                        <div class="widget-content nopadding">
                            <form class="form-horizontal" method="post" action="<?php echo e(url('/admin/add-parts')); ?>" name="add_cars" id="add_cars" novalidate="novalidate">-->

                           <?php echo e(csrf_field()); ?>

                                   
                            <div class="control-group">
                                  <div class="form-group">
                                    <?php echo e(Form::label('brand', 'Markė')); ?>

                                    <?php echo Form::select('car_id', $cars, null,array('class' => 'form-control','required' => 'required') ); ?>

                                </div>
                                </div>
                                <div class="control-group">

                                  <div class="form-group">
                                    <?php echo e(Form::label('w_address', 'Adresas')); ?>

                                    <?php echo Form::select('wh_id', $warehouse, null,array('class' => 'form-control', 'required' => 'required') ); ?>

                                </div>
                                </div>
                               <div class="control-group">
                                  <div class="form-group">
                                    <?php echo e(Form::label('section', 'Detalės vieta')); ?>

                                    <?php echo Form::select('location_id', $location, null,array('class' => 'form-control', 'required' => 'required') ); ?>

                                </div>
                                </div>                                                
                             
                                    <div class="control-group">
                                  <?php echo e(Form::label('p_name', 'Detalės pavadinimas')); ?>

                                   <?php echo e(Form::text('p_name', null, ['class' => 'form-control', 'required' => 'required'])); ?>

                                  </div>
                                   <div class="control-group">
                                    <?php echo e(Form::label('p_price', 'Kaina')); ?>

                                   <?php echo e(Form::number('p_price', null, ['class' => 'form-control', 'min'=>0,'max'=>10000, 'step'=>0.01, 'required' => 'required'])); ?>

                                  </div>   
                                   <div class="control-group">
                                    
                                   <?php echo e(Form::label('p_quantity', 'Kiekis')); ?>

                                   <?php echo e(Form::number('p_quantity', null, ['class' => 'form-control', 'min'=>0, 'max'=>200 ,'required' => 'required'])); ?>

                                    </div>
                                 
                                    <div class="control-group">
                                    <?php echo e(Form::label('p_color', 'Spalva')); ?>

                                   <?php echo e(Form::select('p_color',['Nėra'=>'Nėra','Balta'=>'Balta','Geltona/aukso'=>'Geltona/aukso','Juoda'=>'Juoda','Mėlyna'=>'Mėlyna','Oranžinė'=>'Oranžinė','Pilka/sidabrinė'=>'Pilka/sidabrinė','Raudona/vyšninė'=>'Raudona/vyšninė','Ruda/smėlio'=>'Ruda/smėlio','Violetinė'=>'Violetinė','Žalia/chaki'=>'Žalia/chaki','Kita'=>'Kita'], null, ['class' => 'form-control'])); ?>

                                  </div>
                                  <div class="control-group">
                                    
                                   <?php echo e(Form::label('p_code', 'Detalės kodas')); ?>

                                   <?php echo e(Form::number('p_code', null, ['class' => 'form-control', 'min'=>0, 'max'=>9999999 ,'required' => 'required'])); ?>

                                    </div>
                                    <div class="control-group">
                                    
                                   <?php echo e(Form::label('p_color_code', 'Spalvos kodas')); ?>

                                   <?php echo e(Form::number('p_color_code', null, ['class' => 'form-control', 'min'=>0, 'max'=>99999 ])); ?>

                                    </div>
                                    <div class="control-group">
                                   <?php echo e(Form::label('p_side', 'Detalės pusė')); ?>

                                   <?php echo e(Form::select('p_side',['Nėra'=>'Nėra','Dešinė/Priekis'=>'Dešinė/Priekis', 'Dešinė/Galas'=>'Dešinė/Galas', 'Kairė/Galas'=> 'Kairė/Galas', 'Kairė/Priekis'=>'Kairė/Priekis','Priekis'=> 'Priekis','Galas'=> 'Galas' ], null, ['class' => 'form-control', 'required' => 'required'])); ?>

                                  </div>
                                    <div class="control-group">
                                     <?php echo e(Form::label('p_vendor', 'Gamintojas')); ?>

                                   <?php echo e(Form::select('p_vendor',['Nėra'=>'Nėra','Bosh'=>'Bosh','Dunlop'=>'Dunlop','GoodYear'=> 'GoodYear',  'Kita'=> 'Kita'], null, ['class' => 'form-control', 'required' => 'required'])); ?>

                                  </div>
                               
                                    <div class="control-group">
                                   <?php echo e(Form::label('p_description', 'Aprašymas')); ?>

                                   <?php echo e(Form::text('p_description', null, ['class' => 'form-control', 'required' => 'required'])); ?>

                                  </div>
                                  <div class="control-group">
                                  <label class="control-label">Nuotrauka:</label>
                                  <div class="controls">
                                    <input type="file" class="form-control" name="p_image" id="p_image" accept="image/*">
                                  </div>
                                </div>
                               
                                  &nbsp;
                                <div class="form-actions">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('Sukurti detale')): ?>    <input type="submit" value="Išsaugoti" class="btn btn-primary"> <?php endif; ?>
                                    <a href="<?php echo e(url()->previous()); ?>" class="btn btn-primary">Grįžti atgal</a>
                                </div>
                            </form>
                           
                        </div>
                    </div>
                </div>
        </div>
    </div>

    
    </div>
 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>