<!Doctype html>
  <html lang="en">
   <head>
    <meta charset="UTF-8">
      <title>Dalys</title>
                <style type="text/css">

                          #parts {
                          font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
                          border-collapse: collapse;
                          width: 100%;
                          }

                          #parts td, #parts th {
                              border: 1px solid #ddd;
                              padding: 8px;
                          }

                          #parts tr:nth-child(even){
                            background-color: #f2f2f2;
                          }

                          #parts tr:hover {
                            background-color: #ddd;
                          }

                          #parts th {
                              padding-top: 12px;
                              padding-bottom: 12px;
                              text-align: left;
                              background-color: #4CAF50;
                              color: white;
                          }
              </style>
   </head>

          <body>

            <h1>Dalys</h1>
                            <table id="parts">
                              
                                <thead>
                                <tr>
                                    <th style="width: 5%" >Nr.</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                  
                                   
                                </tr>
                                </thead>
                                <tfoot>
                                <tr>
                                   <th style="width: 5%" >Nr.</th>
                                    <th style="width: 5%" >Automobilio<br> ID</th>
                                    <th style="width: 5%" >Sandėlio<br> ID</th>
                                    <th style="width: 3%">Vietos ID</th>
                                    <th style="width: 10%" >Pavadinimas</th>
                                    <th style="width: 5%" >Kaina</th>
                                    <th style="width: 5%">Kiekis</th>
                                    <th style="width: 8%">Spalva</th>
                                    <th style="width: 8%">Detalės pusė</th>
                                    <th style="width: 8%">Gamintojas</th>
                                    <th style="width: 10%" >Aprašymas</th>
                                    
                                </tr>
                                </tfoot>
                                <tbody>
                                   <?php
                                  $i = 0;
                                  ?>
                                <?php $__currentLoopData = $parts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                               <tr class="gradeX">
                                   <td><?php echo ++$i; ?></td>
                                   <td><?php echo $part -> car_id; ?></td>
                                   <td><?php echo $part -> wh_id; ?></td>
                                   <td><?php echo $part -> location_id; ?></td>
                                   <td><?php echo $part -> p_name; ?></td>
                                   <td><?php echo $part -> p_price; ?></td>
                                   <td><?php echo $part -> p_quantity; ?></td>
                                   <td><?php echo $part -> p_color; ?></td>
                                   <td><?php echo $part -> p_side; ?></td>
                                   <td><?php echo $part -> p_vendor; ?></td>
                                   <td><?php echo $part -> p_description; ?></td>  
                                  
                               </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
       
       
          
          
          </body>
        </html>