<?php $__env->startSection('title', '| Create Permission'); ?>

<?php $__env->startSection('content'); ?>

<div class='col-lg-4 col-lg-offset-4'>
<div class="widget-box">
    <div class="widget-content">
    <h1><i class='fa fa-key'></i> Sukurti leidimą</h1>
    <br>

    <?php echo e(Form::open(array('url' => 'permissions'))); ?>


    <div class="form-group">
        <?php echo e(Form::label('name', 'Pavadinimas')); ?>

        <?php echo e(Form::text('name', '', array('class' => 'form-control'))); ?>

    </div><br>
    <?php if(!$roles->isEmpty()): ?> <!--If no roles exist yet-->
        <h4>Priskirti leidimą prie rolių</h4>

        <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
            <?php echo e(Form::checkbox('roles[]',  $role->id )); ?>

            <?php echo e(Form::label($role->name, ucfirst($role->name))); ?><br>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <br>
    <?php echo e(Form::submit('Išsaugoti', array('class' => 'btn btn-primary'))); ?>


    <?php echo e(Form::close()); ?>


</div>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>