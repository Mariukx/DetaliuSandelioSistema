<?php $__env->startSection('content'); ?>

        <div class="container">
  <h2>Automobilių galerija</h2>
  <h5>Šiuo metu turimi automobiliai ardymui</h5>
 
  <?php $__currentLoopData = $cars->chunk(4); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $chunk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="row">
     <?php $__currentLoopData = $chunk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $car): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-md-3">
      <div class="thumbnail">
        <a href="#myModal<?php echo $car -> car_id; ?>" data-toggle="modal">
          <?php if(!empty($car->image)): ?>
               <img src="<?php echo e(asset('/images/backend_images/cars/small/'.$car->image)); ?>" style="width:auto; height: 200px;">
               <?php else: ?>
               <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:auto; height: 200px;">
          <?php endif; ?>
          <div class="caption" style="background:#F0F8FF; text-align: center;">
            <p><b><?php echo $car -> brand; ?> <?php echo $car -> model; ?> - <?php echo $car -> year; ?> m.</b></p>
          </div>
        </a>
      </div>
    </div>
     <div id="myModal<?php echo $car -> car_id; ?>" class="modal hide "  >
                                          <div class="modal-header" style="height: auto;">
                                            <button data-dismiss="modal" class="close" type="button">×</button>
                                            <h2><?php echo $car -> brand; ?> <?php echo $car -> model; ?> - <?php echo $car -> year; ?> m.</h2>
                                          </div>

                                            <div class="modal-body">
                                            <div class="row">
                                            <div class="col-sm-6"><b>Kuro tipas</b>: <?php echo $car -> fuel; ?></div>
                                            <div class="col-sm-6"><b>Pavarų dėžės tipas</b>: <?php echo $car -> gearbox; ?></div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Kubatūra</b>: <?php echo $car -> cubature; ?> L</div>
                                            <div class="col-sm-6"><b>Galia</b>: <?php echo $car -> power; ?> kW</div>
                                          </div>
                                            <div class="row">  
                                            <div class="col-sm-6"><b>Kėbulo tipas</b>: <?php echo $car -> body_type; ?></div>
                                            <div class="col-sm-6"><b>Spalva</b>: <?php echo $car -> color; ?></div>
                                          </div>
                                            <div class="row">
                                            <div class="col-sm-6"><b>Vairo padėtis</b>: <?php echo $car -> wheel; ?></div>
                                            <div class="col-sm-6"><b>Rida</b>: <?php echo $car -> mileage; ?> km</div>
                                            </div>
                                            <hr>
                                            <a class="btn btn-primary btn-sm" href="<?php echo e(url('/index/parts-gallery/'.$car -> car_id)); ?>" style="text-align: center;"><b>Peržiūrėti detalių sąrašą</b></a>
                                            <div >
                                              <?php if(!empty($car->image)): ?>

                                      <img src="<?php echo e(asset('/images/backend_images/cars/medium/'.$car->image)); ?>" style="width: 90%; height: auto;"  content="width=device-width, initial-scale=1.0">
                                      <?php else: ?>
                                      <div>
                              <img src="<?php echo e(asset('/images/backend_images/nopicture.png')); ?>" style="width:90%; "></div>
                                    <?php endif; ?>
                                  </div>
                                      </div>
                                    </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>







<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>